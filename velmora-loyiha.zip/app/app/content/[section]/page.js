"use client";

import { useCallback, useEffect, useState, useRef } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { getPublishedLessons, getPublishedVocabulary } from "@/lib/api/lessons";
import { ErrorState, EmptyState, LoadingState, Badge } from "@/components/UI";
import { useProfile } from "@/lib/useProfile";
import {
  IconBook,
  IconHeadphones,
  IconEdit,
  IconMic,
  IconVocabulary,
  IconGrammar,
  IconVolume,
  IconClock,
  IconCheckCircle,
  IconSparkles,
  IconPlay,
  IconPause,
  IconRefresh,
  IconArrowRight,
} from "@/components/Icons";

const sectionMeta = {
  reading: { title: "Reading", icon: IconBook, color: "purple", kicker: "Matn tahlili va savol turlari" },
  listening: { title: "Listening", icon: IconHeadphones, color: "teal", kicker: "Audio tinglash va tushunish" },
  writing: { title: "Writing", icon: IconEdit, color: "gold", kicker: "Insho va grafik tahlili" },
  speaking: { title: "Speaking", icon: IconMic, color: "coral", kicker: "Ravon nutq va interaktiv mashqlar" },
  vocabulary: { title: "Vocabulary", icon: IconVocabulary, color: "teal", kicker: "Akademik so‘z boyligi" },
  grammar: { title: "Grammar", icon: IconGrammar, color: "purple", kicker: "Grammatik tuzilmalar va testlar" },
};

// Interactive Flashcard Component for Vocabulary
function VocabularyFlashcard({ word }) {
  const [flipped, setFlipped] = useState(false);
  const [mastered, setMastered] = useState(false);

  function speakWord(e) {
    e.stopPropagation();
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(word.word);
      utterance.lang = "en-US";
      utterance.rate = 0.85;
      window.speechSynthesis.speak(utterance);
    }
  }

  return (
    <div
      className={`vocab-card ${flipped ? "vocab-card-flipped" : ""} ${mastered ? "vocab-card-mastered" : ""}`}
      onClick={() => setFlipped(!flipped)}
    >
      <div className="vocab-card-inner">
        {/* Front of Card */}
        <div className="vocab-card-face vocab-card-front">
          <div className="vocab-face-top">
            <span className="vocab-level-tag">{word.level || "B2"}</span>
            <button
              type="button"
              className="vocab-audio-btn"
              onClick={speakWord}
              title="Talaffuzni eshitish"
            >
              <IconVolume size={18} />
            </button>
          </div>
          <h3 className="vocab-word-title">{word.word}</h3>
          {word.phonetic ? <p className="vocab-phonetic">{word.phonetic}</p> : null}
          <div className="vocab-flip-hint">
            <span>Tarjimasini ko‘rish uchun bosing ↷</span>
          </div>
        </div>

        {/* Back of Card */}
        <div className="vocab-card-face vocab-card-back">
          <div className="vocab-face-top">
            <span className="vocab-cat-tag">{word.category || "Academic"}</span>
            <button
              type="button"
              className={`vocab-master-btn ${mastered ? "mastered" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                setMastered(!mastered);
              }}
              title={mastered ? "O‘rganildi" : "Yodlangan deb belgilash"}
            >
              <IconCheckCircle size={18} />
            </button>
          </div>
          <h4 className="vocab-uzb-trans">{word.translation}</h4>
          {word.definition ? <p className="vocab-def">{word.definition}</p> : null}
          {word.collocations ? (
            <p className="vocab-colloc">
              <strong>Kollokatsiyalar:</strong> {word.collocations}
            </p>
          ) : null}
          {word.example ? <p className="vocab-ex">“{word.example}”</p> : null}
        </div>
      </div>
    </div>
  );
}

// Interactive Speaking Cue Card Simulator with Prep & Speaking Timers
function SpeakingSimulator({ lesson }) {
  const [stage, setStage] = useState("idle"); // idle, preparing, speaking, finished
  const [timer, setTimer] = useState(60);
  const [isRecording, setIsRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);

  useEffect(() => {
    let interval;
    if (stage === "preparing" && timer > 0) {
      interval = setInterval(() => setTimer((t) => t - 1), 1000);
    } else if (stage === "preparing" && timer === 0) {
      setStage("speaking");
      setTimer(120);
    } else if (stage === "speaking" && timer > 0) {
      interval = setInterval(() => setTimer((t) => t - 1), 1000);
    } else if (stage === "speaking" && timer === 0) {
      setStage("finished");
      stopRecording();
    }
    return () => clearInterval(interval);
  }, [stage, timer]);

  async function startPractice() {
    setStage("preparing");
    setTimer(60);
    setAudioUrl(null);
    audioChunksRef.current = [];

    // Optional audio recording
    if (typeof navigator !== "undefined" && navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorderRef.current = new MediaRecorder(stream);
        mediaRecorderRef.current.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunksRef.current.push(e.data);
        };
        mediaRecorderRef.current.onstop = () => {
          const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
          setAudioUrl(URL.createObjectURL(blob));
        };
      } catch (err) {
        console.warn("Mikrofonga ruxsat berilmadi:", err);
      }
    }
  }

  function startSpeakingNow() {
    setStage("speaking");
    setTimer(120);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "inactive") {
      try {
        mediaRecorderRef.current.start();
        setIsRecording(true);
      } catch (e) {}
    }
  }

  function stopRecording() {
    setStage("finished");
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      try {
        mediaRecorderRef.current.stop();
        setIsRecording(false);
      } catch (e) {}
    }
  }

  const sample = lesson.cueCardSample || {
    topic: "Describe a memorable book you have read recently.",
    prompts: ["What book was it?", "Who wrote it?", "What was the plot about?", "Why did it leave an impression?"],
  };

  return (
    <div className="speaking-simulator glass-card">
      <div className="sim-header">
        <span className="badge-coral">Speaking Part 2 Simulyatori</span>
        <div className="sim-timer-display">
          <IconClock size={18} />
          <strong>
            {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, "0")}
          </strong>
          <span>({stage === "preparing" ? "Tayyorgarlik" : stage === "speaking" ? "Nutq vaqti" : "Tayyor"})</span>
        </div>
      </div>

      <div className="cue-card-box">
        <h3>{sample.topic}</h3>
        <p className="cue-subtitle">Siz quyidagilar haqida gapirishingiz kerak:</p>
        <ul className="cue-points">
          {sample.prompts.map((p, idx) => (
            <li key={idx}>{p}</li>
          ))}
        </ul>
      </div>

      <div className="sim-controls">
        {stage === "idle" && (
          <button className="button" type="button" onClick={startPractice}>
            <IconPlay size={18} /> Mashqni boshlash (1 daqiqa tayyorgarlik)
          </button>
        )}
        {stage === "preparing" && (
          <button className="button button-secondary" type="button" onClick={startSpeakingNow}>
            Tayyorman, nutqni boshlash (2 daqiqa) →
          </button>
        )}
        {stage === "speaking" && (
          <button className="button button-danger" type="button" onClick={stopRecording}>
            <IconPause size={18} /> Nutqni yakunlash
          </button>
        )}
        {stage === "finished" && (
          <button className="button button-quiet" type="button" onClick={() => setStage("idle")}>
            <IconRefresh size={18} /> Qaytadan boshlash
          </button>
        )}
      </div>

      {audioUrl && (
        <div className="recorded-audio-box">
          <h4>Ovoz yozuvingiz:</h4>
          <audio controls src={audioUrl} />
          <p>O‘z nutqingizni eshitib, ravonlik va grammatik xatolarni tekshirib chiqing.</p>
        </div>
      )}

      {sample.band9Idioms && (
        <div className="cue-idioms">
          <strong>Band 9.0 Foydali iboralar:</strong>
          <div className="idiom-tags">
            {sample.band9Idioms.map((idm, i) => (
              <span key={i} className="idiom-chip">
                {idm}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Interactive Mini-Quiz for Lessons
function MiniQuiz({ task }) {
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  if (!task) return null;

  return (
    <div className="mini-quiz-box">
      <div className="quiz-header">
        <IconSparkles size={18} />
        <strong>Mavzu bo‘yicha tezkor savol</strong>
      </div>
      <p className="quiz-question">{task.question}</p>
      <div className="quiz-options">
        {task.options.map((opt, idx) => {
          const isSelected = selected === idx;
          const isCorrect = submitted && idx === task.answer;
          const isWrong = submitted && isSelected && idx !== task.answer;
          return (
            <button
              key={idx}
              type="button"
              className={`quiz-opt-btn ${isSelected ? "selected" : ""} ${isCorrect ? "correct" : ""} ${
                isWrong ? "wrong" : ""
              }`}
              onClick={() => {
                if (!submitted) setSelected(idx);
              }}
            >
              <span className="opt-marker">{String.fromCharCode(65 + idx)}</span>
              <span>{opt}</span>
            </button>
          );
        })}
      </div>
      <div className="quiz-actions">
        {!submitted ? (
          <button
            type="button"
            className="button button-small"
            disabled={selected === null}
            onClick={() => setSubmitted(true)}
          >
            Javobni tekshirish
          </button>
        ) : (
          <div className="quiz-feedback">
            {selected === task.answer ? (
              <span className="feedback-correct">✓ To‘g‘ri javob! Barakalla!</span>
            ) : (
              <span className="feedback-wrong">✕ Noto‘g‘ri. To‘g‘ri variant: {task.options[task.answer]}</span>
            )}
            <button
              type="button"
              className="text-link"
              onClick={() => {
                setSubmitted(false);
                setSelected(null);
              }}
            >
              Qayta urinish
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ContentPage() {
  const params = useParams();
  const sectionKey = String(params.section || "").toLowerCase();
  const meta = sectionMeta[sectionKey] || {
    title: sectionKey.toUpperCase(),
    icon: IconBook,
    color: "purple",
    kicker: "O‘quv bo‘limi",
  };
  const Icon = meta.icon;

  const { profile, loading: profileLoading, error: profileError } = useProfile({
    requireAuth: false,
    requireOnboarding: false,
  });

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [vocabFilter, setVocabFilter] = useState("all");
  const [vocabSearch, setVocabSearch] = useState("");

  const track = profile?.track || "ielts";
  const level = profile?.target_level || null;

  const loadContent = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      if (sectionKey === "vocabulary") {
        const result = await getPublishedVocabulary({ track, level });
        setItems(result);
      } else {
        const result = await getPublishedLessons({
          track,
          level,
          section: meta.title,
        });
        setItems(result);
      }
    } catch (loadError) {
      setError(loadError.message || "Kontentni yuklab bo‘lmadi.");
    } finally {
      setLoading(false);
    }
  }, [track, level, meta.title, sectionKey]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const filteredVocab = items.filter((item) => {
    if (vocabFilter !== "all" && item.level !== vocabFilter) return false;
    if (vocabSearch.trim()) {
      const q = vocabSearch.toLowerCase();
      const matchWord = item.word?.toLowerCase().includes(q);
      const matchTrans = item.translation?.toLowerCase().includes(q);
      return matchWord || matchTrans;
    }
    return true;
  });

  return (
    <section className="container page-wrap">
      {/* SECTION HEADER */}
      <div className="content-section-head">
        <div className="head-text">
          <Link href="/dashboard" className="back-bread">
            ← Dashboard’ga qaytish
          </Link>
          <div className="section-title-wrap">
            <span className={`content-hero-icon icon-${meta.color}`}>
              <Icon size={28} />
            </span>
            <div>
              <span className="section-kicker">{meta.kicker}</span>
              <h1 className="page-title">{meta.title} Bo‘limi</h1>
            </div>
          </div>
          <p className="page-intro">
            {track.toUpperCase()} yo‘nalishi bo‘yicha tanlangan professional darslar, tahliliy usullar va interaktiv mashqlar.
          </p>
        </div>

        <div className="section-cta-card glass-card">
          <span>O‘quv darajangiz:</span>
          <strong>{track.toUpperCase()} {level ? `(Maqsad: ${level})` : ""}</strong>
          {sectionKey === "writing" && (
            <Link className="button button-small" href="/writing">
              Writing Simulyatori →
            </Link>
          )}
          {sectionKey === "reading" && (
            <Link className="button button-small" href="/practice">
              Reading Mini-Test →
            </Link>
          )}
        </div>
      </div>

      {error ? <ErrorState message={error} onRetry={loadContent} /> : null}

      {/* VOCABULARY SECTION SPECIFIC CONTROLS */}
      {sectionKey === "vocabulary" && (
        <div className="vocab-toolbar glass-card">
          <div className="vocab-search-wrap">
            <input
              type="text"
              placeholder="So‘z yoki tarjimasini qidirish..."
              value={vocabSearch}
              onChange={(e) => setVocabSearch(e.target.value)}
              className="vocab-search-input"
            />
          </div>
          <div className="vocab-level-filter">
            <span>Daraja:</span>
            {["all", "B1", "B2", "C1"].map((lvl) => (
              <button
                key={lvl}
                type="button"
                className={`filter-chip ${vocabFilter === lvl ? "active" : ""}`}
                onClick={() => setVocabFilter(lvl)}
              >
                {lvl === "all" ? "Barchasi" : lvl}
              </button>
            ))}
          </div>
        </div>
      )}

      {loading ? (
        <LoadingState label={`${meta.title} materiallari yuklanmoqda...`} />
      ) : null}

      {/* RENDER CONTENT */}
      {!loading && sectionKey === "vocabulary" && (
        <div className="vocab-grid">
          {filteredVocab.map((w) => (
            <VocabularyFlashcard key={w.id || w.word} word={w} />
          ))}
          {filteredVocab.length === 0 && (
            <div className="empty-wrap">
              <EmptyState title="So‘zlar topilmadi" description="Qidiruv so‘zini o‘zgartirib ko‘ring." />
            </div>
          )}
        </div>
      )}

      {!loading && sectionKey !== "vocabulary" && (
        <div className="content-lessons-grid">
          {items.map((lesson) => (
            <article className="glass-card lesson-detailed-card" key={lesson.id || lesson.title}>
              <div className="lesson-top-row">
                <span className="lesson-track-tag">
                  {lesson.track?.toUpperCase() || "IELTS"} · {lesson.level || "Band 7.0+"}
                </span>
                {lesson.video_url && (
                  <a
                    className="lesson-video-link"
                    href={lesson.video_url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <span>Video tahlil ↗</span>
                  </a>
                )}
              </div>

              <h2 className="lesson-title">{lesson.title}</h2>
              {lesson.description && <p className="lesson-desc">{lesson.description}</p>}

              {lesson.tips && (
                <div className="lesson-tips-box">
                  <strong>Ekspert maslahatlari:</strong>
                  <ul>
                    {lesson.tips.map((tip, i) => (
                      <li key={i}>{tip}</li>
                    ))}
                  </ul>
                </div>
              )}

              {lesson.modelOutline && (
                <div className="lesson-outline-box">
                  <strong>Insho strukturasi (PEEL):</strong>
                  <div className="outline-steps">
                    <div><b>Introduction:</b> {lesson.modelOutline.intro}</div>
                    <div><b>Body 1:</b> {lesson.modelOutline.body1}</div>
                    <div><b>Body 2:</b> {lesson.modelOutline.body2}</div>
                    <div><b>Conclusion:</b> {lesson.modelOutline.conclusion}</div>
                  </div>
                </div>
              )}

              {lesson.audioSample && (
                <div className="lesson-audio-box">
                  <h4>{lesson.audioSample.title}</h4>
                  <pre className="audio-script">{lesson.audioSample.script}</pre>
                  <MiniQuiz
                    task={{
                      question: lesson.audioSample.question,
                      options: lesson.audioSample.options,
                      answer: lesson.audioSample.answer,
                    }}
                  />
                </div>
              )}

              {sectionKey === "speaking" && lesson.cueCardSample && (
                <SpeakingSimulator lesson={lesson} />
              )}

              {lesson.interactiveTask && <MiniQuiz task={lesson.interactiveTask} />}
            </article>
          ))}

          {items.length === 0 && (
            <EmptyState
              title={`${meta.title} bo‘yicha darslar topilmadi`}
              description="Tez orada ustozlarimiz yangi darslarni joylaydilar."
              action="Bosh sahifaga qaytish"
              href="/"
            />
          )}
        </div>
      )}
    </section>
  );
}
