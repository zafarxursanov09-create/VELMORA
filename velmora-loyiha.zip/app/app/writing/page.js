"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ErrorState, LoadingState, Badge } from "@/components/UI";
import { createWritingSubmission, getWritingSubmissions } from "@/lib/api/progress";
import { useProfile } from "@/lib/useProfile";
import {
  IconEdit,
  IconCheckCircle,
  IconSparkles,
  IconClock,
  IconBook,
  IconArrowRight,
  IconRefresh,
} from "@/components/Icons";

const promptsList = [
  {
    id: "ielts-writing-task2-transport-v1",
    taskType: "Task 2 (Opinion)",
    title: "Investment in Public Transport vs Roads",
    prompt:
      "Some people believe that governments should invest more money in public transport infrastructure than in expanding road networks. To what extent do you agree or disagree?",
    minWords: 250,
    modelAnswer: `In contemporary urban planning, the allocation of state funds towards transportation infrastructure remains a contentious issue. While some argue that expanding roadways alleviates traffic, I firmly agree that governments should prioritize substantial investment in public transport networks due to environmental sustainability and long-term socio-economic efficiency.

Firstly, a well-developed public transit network significantly mitigates carbon emissions and air pollution. Private automobiles represent one of the primary contributors to greenhouse gases in metropolitan areas. When governments invest in extensive subway lines, electric buses, and high-speed rail, citizens are naturally incentivized to commute collectively rather than individually. For instance, cities like Tokyo and Singapore have curtailed vehicular emissions dramatically by providing accessible, punctual rail services.

Furthermore, expanding road systems often induces additional traffic demand, a phenomenon recognized by urban economists. Adding extra highway lanes may relieve congestion temporarily, but it inevitably encourages more citizens to purchase vehicles, resulting in gridlock within a few years. Conversely, high-capacity public transit optimizes urban space, allowing millions of citizens to travel efficiently without consuming vast tracts of municipal land for parking lots and expressways.

In conclusion, although maintaining baseline road safety is necessary, dedicating the majority of public expenditure to comprehensive transit networks yields superior environmental and social returns. Governments must therefore direct fiscal policy towards sustainable mobility.`,
  },
  {
    id: "ielts-writing-task2-tech-education",
    taskType: "Task 2 (Discussion)",
    title: "Technology in Classrooms vs Traditional Teachers",
    prompt:
      "Some people argue that technological devices in classrooms enhance learning, while others believe they cause unnecessary distractions. Discuss both views and give your own opinion.",
    minWords: 250,
    modelAnswer: `The proliferation of digital gadgets in educational settings has sparked an intense global debate. While detractors emphasize the potential for distraction and reduced concentration, proponents contend that digital tools democratize knowledge and facilitate interactive learning. In my view, when regulated with clear pedagogical guidelines, technology provides indispensable advantages for contemporary students.

On the one hand, unregulated access to smartphones and tablets can undoubtedly disrupt academic focus. Adolescents are naturally susceptible to social media alerts, online gaming, and superficial multitasking during lectures. Research has indicated that frequent digital interruptions diminish deep comprehension and undermine handwriting dexterity. Consequently, without strict teacher oversight, classroom devices risk degrading educational outcomes.

On the other hand, educational software enables unprecedented personalization. Interactive simulations allow students to visualize complex mathematical theories or biological processes in three dimensions. Moreover, digital platforms connect learners from developing regions with premier open-source university libraries, eliminating geographical barriers. For example, gamified language software has empowered millions to acquire foreign languages far more rapidly than conventional textbooks.

To summarize, while the danger of digital distraction is genuine, outright prohibition is counterproductive. Educational authorities should establish structured device protocols while leveraging technology to enrich curricular engagement.`,
  },
  {
    id: "ielts-writing-task1-academic-energy",
    taskType: "Task 1 (Academic)",
    title: "Global Renewable Energy Trends (2010 - 2024)",
    prompt:
      "The chart demonstrates the proportion of electricity generated from renewable sources across four regions between 2010 and 2024. Summarize the information by selecting and reporting the main features, and make comparisons where relevant.",
    minWords: 150,
    modelAnswer: `The provided line graph illustrates the percentage of electricity produced from sustainable sources in four distinct regions from 2010 to 2024.

Overall, it is immediately apparent that all four regions experienced an upward trajectory in clean energy generation throughout the period. Europe consistently maintained the highest share, while Asia registered the most dramatic acceleration.

In 2010, Europe led the chart with approximately 22% of its electricity originating from renewables, rising steadily to peak at 44% in 2024. North America followed a comparable pattern, commencing at 15% and climbing gradually to reach roughly 28% by the final year.

By contrast, Asia started from a modest base of only 8% in 2010. However, after 2016, renewable investments in the region surged, culminating in an impressive 35% in 2024, thereby surpassing North America. Lastly, Latin America demonstrated consistent, moderate growth, advancing from 12% to 22% over the fourteen-year timeframe.`,
  },
];

const academicLinkers = [
  "however",
  "moreover",
  "furthermore",
  "consequently",
  "therefore",
  "although",
  "whereas",
  "nevertheless",
  "in addition",
  "on the other hand",
  "conversely",
];

function getWordCount(text) {
  return text.trim() ? text.trim().split(/\s+/).length : 0;
}

function analyzeWriting(text, minWords) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const paragraphs = text
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean);
  const sentences = text
    .split(/[.!?]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const feedback = [];
  let scorePoints = 5.0;

  // 1. Task length
  if (wordCount < minWords) {
    feedback.push(`Hajm: ${wordCount} ta so‘z. Minimal talab (${minWords} so‘z) bajarilmadi.`);
  } else {
    feedback.push(`Hajm: ${wordCount} ta so‘z. Minimal talab muvaffaqiyatli bajarildi.`);
    scorePoints += 1.0;
  }

  // 2. Paragraph structure
  if (paragraphs.length < 3) {
    feedback.push("Struktura: Kirish, asosiy fikrlar va xulosa uchun alohida paragraflarga ajrating.");
  } else {
    feedback.push(`Struktura: ${paragraphs.length} ta aniq paragraf shakllantirilgan.`);
    scorePoints += 0.5;
  }

  // 3. Linkers / Cohesion
  const lowerText = text.toLowerCase();
  const matchedLinkers = academicLinkers.filter((l) => lowerText.includes(l));
  if (matchedLinkers.length < 3) {
    feedback.push("Bog‘lovchilar: Fikrlar o‘rtasidagi mantiqiy aloqani ko‘rsatuvchi iboralar (However, Furthermore, Consequently) kam qo‘llangan.");
  } else {
    feedback.push(`Bog‘lovchilar: ${matchedLinkers.length} xil akademik bog‘lovchi aniqlandi.`);
    scorePoints += 0.5;
  }

  // 4. Sentence complexity
  const avgSentenceLength = sentences.length ? Math.round(words.length / sentences.length) : 0;
  if (avgSentenceLength > 12 && avgSentenceLength < 28) {
    scorePoints += 0.5;
    feedback.push(`Gap tuzilmasi: O‘rtacha ${avgSentenceLength} so‘z. Murakkab va qo‘shma gaplar balansi yaxshi.`);
  } else {
    feedback.push(`Gap tuzilmasi: O‘rtacha ${avgSentenceLength} so‘z. Gaplar juda qisqa yoki haddan ortiq uzun.`);
  }

  const estimatedBand = Math.min(8.5, Math.max(5.0, Math.round(scorePoints * 2) / 2)).toFixed(1);

  return { feedback, estimatedBand, wordCount, paragraphCount: paragraphs.length, matchedLinkers };
}

export default function WritingPage() {
  const { user, loading: profileLoading } = useProfile({
    requireAuth: true,
    requireOnboarding: true,
  });

  const [selectedPromptIdx, setSelectedPromptIdx] = useState(0);
  const currentPrompt = promptsList[selectedPromptIdx];

  const [draft, setDraft] = useState("");
  const [submissions, setSubmissions] = useState([]);
  const [analysis, setAnalysis] = useState(null);
  const [showModelAnswer, setShowModelAnswer] = useState(false);
  const [loadingSubmissions, setLoadingSubmissions] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const wordCount = getWordCount(draft);

  useEffect(() => {
    if (profileLoading || !user) return undefined;
    let active = true;
    getWritingSubmissions(user.uid)
      .then((items) => {
        if (active) setSubmissions(items);
      })
      .catch((loadError) => {
        if (active) setError(loadError.message || "Yozuvlar tarixini yuklab bo‘lmadi.");
      })
      .finally(() => {
        if (active) setLoadingSubmissions(false);
      });
    return () => {
      active = false;
    };
  }, [profileLoading, user]);

  function reviewDraft() {
    if (!draft.trim()) return;
    const res = analyzeWriting(draft, currentPrompt.minWords);
    setAnalysis(res);
    setSuccess("");
  }

  async function submitDraft(e) {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!user) {
      setError("Topshirish uchun tizimga kirgan bo‘lishingiz kerak.");
      return;
    }

    if (draft.trim().length < 100) {
      setError("Insho matni kamida 100 belgidan iborat bo‘lishi kerak.");
      return;
    }

    const res = analyzeWriting(draft, currentPrompt.minWords);
    setAnalysis(res);

    setSaving(true);
    try {
      const savedDoc = await createWritingSubmission(user.uid, {
        promptId: currentPrompt.id,
        promptTitle: currentPrompt.title,
        body: draft,
        wordCount,
        feedback: res.feedback,
      });

      setSubmissions((prev) => [savedDoc, ...prev]);
      setSuccess("Insho topshirildi va bazaga saqlandi!");
    } catch (submitErr) {
      setError(submitErr.message || "Inshoni saqlashda xatolik yuz berdi.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="container page-wrap">
      {/* HEADER */}
      <div className="writing-header glass-card">
        <div>
          <span className="section-kicker">IELTS Writing Laboratoriyasi</span>
          <h1 className="page-title">Insho va Hisobot Yozish Simulyatori</h1>
          <p className="page-intro">
            Vaqt va so‘zlar hisoblagichi, 4 ta baholash mezoni bo‘yicha tahlil hamda Band 9.0 namunalar.
          </p>
        </div>

        <div className="prompt-picker-tabs">
          {promptsList.map((p, idx) => (
            <button
              key={p.id}
              type="button"
              className={`prompt-tab-btn ${selectedPromptIdx === idx ? "active" : ""}`}
              onClick={() => {
                setSelectedPromptIdx(idx);
                setAnalysis(null);
                setShowModelAnswer(false);
              }}
            >
              <span>{p.taskType}</span>
              <small>{p.title}</small>
            </button>
          ))}
        </div>
      </div>

      {error ? <ErrorState message={error} /> : null}
      {success ? <div className="notice notice-success">{success}</div> : null}

      <div className="writing-layout">
        {/* LEFT COLUMN: PROMPT & EDITOR */}
        <div className="writing-editor-col">
          {/* Active Prompt Box */}
          <div className="glass-card active-prompt-card">
            <div className="prompt-topline">
              <span className="badge-gold">{currentPrompt.taskType}</span>
              <span className="prompt-min-words">Talab: kamida {currentPrompt.minWords} so‘z</span>
            </div>
            <h3>{currentPrompt.prompt}</h3>
          </div>

          {/* Text Area & Live Metrics */}
          <div className="glass-card writing-box">
            <div className="writing-metrics-bar">
              <div className="metric-pill">
                <span>So‘zlar soni:</span>
                <strong className={wordCount < currentPrompt.minWords ? "text-warn" : "text-success"}>
                  {wordCount} / {currentPrompt.minWords}
                </strong>
              </div>
              <div className="metric-progress-track">
                <span
                  style={{
                    width: `${Math.min(100, (wordCount / currentPrompt.minWords) * 100)}%`,
                  }}
                />
              </div>
            </div>

            <textarea
              className="writing-textarea"
              placeholder="Inshongizni shu yerga yozing..."
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={16}
            />

            <div className="writing-actions-row">
              <button
                type="button"
                className="button button-secondary"
                onClick={reviewDraft}
                disabled={wordCount < 10}
              >
                <IconSparkles size={18} /> Tekshirish & Tahlil
              </button>

              <button
                type="button"
                className="button"
                onClick={submitDraft}
                disabled={saving || wordCount < 50}
              >
                {saving ? "Saqlanmoqda..." : "Bazaga saqlash & Topshirish"}
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: ANALYSIS & MODEL ANSWER */}
        <div className="writing-sidebar-col">
          {/* Analysis Card */}
          {analysis && (
            <div className="glass-card analysis-card">
              <div className="analysis-header">
                <div>
                  <span className="section-kicker">Taxminiy Band</span>
                  <h2>Band {analysis.estimatedBand}</h2>
                </div>
                <span className="analysis-status-pill">IELTS Mezonlari</span>
              </div>

              <div className="analysis-feedback-list">
                {analysis.feedback.map((item, idx) => (
                  <div key={idx} className="analysis-feedback-item">
                    <IconCheckCircle size={18} />
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              {analysis.matchedLinkers.length > 0 && (
                <div className="analysis-linkers-box">
                  <strong>Topilgan bog‘lovchilar:</strong>
                  <div className="linker-tags">
                    {analysis.matchedLinkers.map((l) => (
                      <span key={l} className="linker-tag">
                        {l}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Model Answer Toggle Card */}
          <div className="glass-card model-answer-card">
            <div className="model-head">
              <div>
                <span className="section-kicker">Band 9.0 Namunasi</span>
                <h4>Ekspert inshosi bilan solishtiring</h4>
              </div>
              <button
                type="button"
                className="button button-small button-quiet"
                onClick={() => setShowModelAnswer(!showModelAnswer)}
              >
                {showModelAnswer ? "Yashirish" : "Namuna insho ↗"}
              </button>
            </div>

            {showModelAnswer && (
              <div className="model-answer-content">
                {currentPrompt.modelAnswer.split("\n\n").map((para, idx) => (
                  <p key={idx}>{para}</p>
                ))}
              </div>
            )}
          </div>

          {/* Submissions History */}
          <div className="glass-card writing-history-card">
            <h4>Saqlangan insholar tarixi</h4>
            {loadingSubmissions ? (
              <p>Tarix yuklanmoqda...</p>
            ) : submissions.length === 0 ? (
              <p className="empty-history-text">Hali saqlangan insho yo‘q.</p>
            ) : (
              <div className="submissions-list">
                {submissions.slice(0, 4).map((sub) => (
                  <div key={sub.id} className="history-item">
                    <div>
                      <strong>{sub.prompt_title}</strong>
                      <small>{sub.word_count} so‘z</small>
                    </div>
                    <time>{new Date(sub.created_at).toLocaleDateString("uz-UZ")}</time>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}