"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ErrorState, LoadingState, Badge } from "@/components/UI";
import { createLiveClass, getLiveClasses } from "@/lib/api/classes";
import { useProfile } from "@/lib/useProfile";
import {
  IconVideo,
  IconPlay,
  IconClock,
  IconCheckCircle,
  IconSparkles,
  IconArrowRight,
} from "@/components/Icons";


function safeWebUrl(value) {
  if (!value.trim()) return true;
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function formatClassDate(value) {
  try {
    const date = new Date(value);
    return new Intl.DateTimeFormat("uz-UZ", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(date);
  } catch (e) {
    return value;
  }
}

export default function ClassesPage() {
  const { user, profile, loading: profileLoading, error: profileError } = useProfile({
    requireAuth: false,
  });

  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [filter, setFilter] = useState("all"); // all, upcoming, recorded

  // Teacher creation form
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [startAt, setStartAt] = useState("");
  const [meetingUrl, setMeetingUrl] = useState("");
  const [recordingUrl, setRecordingUrl] = useState("");
  const [saving, setSaving] = useState(false);

  const loadClasses = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const result = await getLiveClasses(user?.uid || "", profile?.role || "student");
      if (result && result.length > 0) {
        setClasses(result);
      } else {
        setClasses([]);
      }
    } catch (loadError) {
      console.warn("Darslar Firestore'dan yuklanmadi, zaxira darslar qo‘yildi:", loadError);
      setClasses([]);
    } finally {
      setLoading(false);
    }
  }, [profile, user]);

  useEffect(() => {
    loadClasses();
  }, [loadClasses]);

  async function handleCreateClass(e) {
    e.preventDefault();
    setError("");
    setNotice("");

    if (!safeWebUrl(meetingUrl) || !safeWebUrl(recordingUrl)) {
      setError("Uchrashuv va video manzillari http:// yoki https:// bilan boshlanishi kerak.");
      return;
    }

    if (!meetingUrl.trim() && !recordingUrl.trim()) {
      setError("Jonli uchrashuv havolasi yoki video yozuvi havolasidan kamida bittasini kiriting.");
      return;
    }

    setSaving(true);
    try {
      const created = await createLiveClass(user.uid, profile.full_name || "Ustoz", {
        title: title.trim(),
        description: description.trim(),
        startAt,
        meetingUrl: meetingUrl.trim(),
        recordingUrl: recordingUrl.trim(),
      });

      setClasses((prev) => [created, ...prev]);
      setNotice("Dars muvaffaqiyatli jadvalga qo‘shildi!");
      setTitle("");
      setDescription("");
      setStartAt("");
      setMeetingUrl("");
      setRecordingUrl("");
    } catch (createErr) {
      setError(createErr.message || "Darsni qo‘shishda xatolik.");
    } finally {
      setSaving(false);
    }
  }

  const isTeacher = profile?.role === "teacher" || profile?.role === "admin";

  const filteredClasses = classes.filter((c) => {
    if (filter === "upcoming") return Boolean(c.meeting_url);
    if (filter === "recorded") return Boolean(c.recording_url);
    return true;
  });

  return (
    <section className="container page-wrap">
      {/* HEADER */}
      <div className="classes-hero-head glass-card">
        <div>
          <span className="section-kicker">Jonli Mashg‘ulotlar</span>
          <h1 className="page-title">Onlayn Vebinarlar & Dars Yozuvlari</h1>
          <p className="page-intro">
            IELTS Band 9.0 ustozlaridan jonli mahorat darslari, savol-javob sessiyalari va arxiv video darslari.
          </p>
        </div>

        <div className="class-filter-pills">
          <button
            type="button"
            className={`filter-pill ${filter === "all" ? "active" : ""}`}
            onClick={() => setFilter("all")}
          >
            Barchasi ({classes.length})
          </button>
          <button
            type="button"
            className={`filter-pill ${filter === "upcoming" ? "active" : ""}`}
            onClick={() => setFilter("upcoming")}
          >
            Rejalashtirilgan
          </button>
          <button
            type="button"
            className={`filter-pill ${filter === "recorded" ? "active" : ""}`}
            onClick={() => setFilter("recorded")}
          >
            Video Yozuvlar
          </button>
        </div>
      </div>

      {error ? <ErrorState message={error} /> : null}
      {notice ? <div className="notice notice-success">{notice}</div> : null}

      {/* TEACHER SCHEDULER ACCORDION */}
      {isTeacher && (
        <details className="glass-card teacher-schedule-accordion">
          <summary>
            <strong>+ Yangi jonli dars yoki yozuv e’lon qilish (Ustoz paneli)</strong>
          </summary>
          <form onSubmit={handleCreateClass} className="schedule-form">
            <label className="form-field">
              Dars mavzusi:
              <input
                required
                type="text"
                minLength={4}
                maxLength={120}
                placeholder="Masalan: IELTS Writing Task 2 Masterclass"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </label>

            <label className="form-field">
              Qisqacha tavsif:
              <textarea
                required
                maxLength={1000}
                placeholder="Darsda nimalar o‘rganiladi va kimlar uchun mo‘ljallangan..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </label>

            <div className="form-grid">
              <label className="form-field">
                Boshlanish vaqti:
                <input
                  type="datetime-local"
                  value={startAt}
                  onChange={(e) => setStartAt(e.target.value)}
                />
              </label>

              <label className="form-field">
                Jonli uchrashuv havolasi (Google Meet / Zoom):
                <input
                  type="url"
                  placeholder="https://meet.google.com/..."
                  value={meetingUrl}
                  onChange={(e) => setMeetingUrl(e.target.value)}
                />
              </label>

              <label className="form-field">
                Yozib olingan video havolasi (YouTube / Drive):
                <input
                  type="url"
                  placeholder="https://youtube.com/..."
                  value={recordingUrl}
                  onChange={(e) => setRecordingUrl(e.target.value)}
                />
              </label>
            </div>

            <button type="submit" className="button" disabled={saving}>
              {saving ? "E’lon qilinmoqda..." : "Darsni jadvalga qo‘shish"}
            </button>
          </form>
        </details>
      )}

      {loading ? (
        <LoadingState label="Darslar jadvali yuklanmoqda..." />
      ) : (
        <div className="classes-grid">
          {filteredClasses.map((item) => {
            const isLive = Boolean(item.meeting_url);
            const isRecorded = Boolean(item.recording_url);

            return (
              <article className="glass-card class-card" key={item.id}>
                <div className="class-card-top">
                  <span className={isLive ? "badge-coral" : "badge-purple"}>
                    {isLive ? "● Jonli Uchrashuv" : "▶ Video Yozuv"}
                  </span>
                  <span className="class-date">
                    <IconClock size={16} /> {formatClassDate(item.start_at)}
                  </span>
                </div>

                <h3 className="class-title">{item.title}</h3>
                <p className="class-teacher">Ustoz: <strong>{item.teacher_name}</strong></p>
                <p className="class-desc">{item.description}</p>

                <div className="class-actions">
                  {item.meeting_url && (
                    <a
                      className="button button-small"
                      href={item.meeting_url}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <IconVideo size={16} /> Uchrashuvga ulanish ↗
                    </a>
                  )}
                  {item.recording_url && (
                    <a
                      className="button button-small button-secondary"
                      href={item.recording_url}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <IconPlay size={16} /> Yozuvni ko‘rish ↗
                    </a>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}