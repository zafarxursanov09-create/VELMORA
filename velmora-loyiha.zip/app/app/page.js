"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getPublishedBandNineTeachers } from "@/lib/api/teachers";
import { ErrorState, EmptyState, LoadingState } from "@/components/UI";
import {
  IconBook,
  IconHeadphones,
  IconEdit,
  IconMic,
  IconVocabulary,
  IconGrammar,
  IconTarget,
  IconSparkles,
  IconFlame,
  IconCheckCircle,
  IconClock,
  IconAward,
  IconArrowRight,
} from "@/components/Icons";

const features = [
  {
    num: "01",
    title: "Shaxsiylashtirilgan o‘quv rejasi",
    desc: "IELTS yoki CEFR maqsadli balingizni belgilang. Dashboard sizning darajangizga moslashtirilgan darslar va so‘zlarni taqdim etadi.",
  },
  {
    num: "02",
    title: "To‘rt asosiy ko‘nikma",
    desc: "Listening, Reading, Writing va Speaking bo‘yicha to‘liq tayyorgarlik tizimi, nazariy qoidalar va real amaliyot.",
  },
  {
    num: "03",
    title: "Interaktiv Lug‘at & Flashcards",
    desc: "Talaffuz audiosi, O‘zbekcha tarjima, kollokatsiyalar va misollar bilan akademik so‘zlarni samarali yodlang.",
  },
  {
    num: "04",
    title: "Vaqt bilan nazorat qilinadigan testlar",
    desc: "IELTS Reading va CEFR diagnostik testlarini real imtihon muhitida topshiring va natijalarni bazada saqlang.",
  },
];

const learningAreas = [
  {
    title: "Reading",
    desc: "Matnlarni tahlil qilish, skimming & scanning va True/False/Not Given savol turlari.",
    tag: "Lavhalar va tahlil",
    icon: IconBook,
    color: "purple",
    href: "/practice",
  },
  {
    title: "Listening",
    desc: "Audio dialoglar, transkriptlar va diqqatni jamlash bo‘yicha professional tavsiyalar.",
    tag: "Tinglab tushunish",
    icon: IconHeadphones,
    color: "teal",
    href: "/content/listening",
  },
  {
    title: "Writing",
    desc: "Task 1 grafiklarni tasvirlash va Task 2 insho simulyatori, real vaqt so‘z hisoblagichi.",
    tag: "Task 1 & Task 2",
    icon: IconEdit,
    color: "gold",
    href: "/writing",
  },
  {
    title: "Speaking",
    desc: "Part 1, Part 2 Cue card 2 daqiqalik nutq tayyorgarligi va Part 3 tahliliy suhbatlar.",
    tag: "Ravon nutq & Ovoz yozish",
    icon: IconMic,
    color: "coral",
    href: "/content/speaking",
  },
  {
    title: "Vocabulary",
    desc: "Band 7.0-9.0 akademik so‘zlar, ovozli talaffuz va interaktiv kartalar.",
    tag: "Akademik so‘zlar",
    icon: IconVocabulary,
    color: "teal",
    href: "/content/vocabulary",
  },
  {
    title: "Grammar",
    desc: "Inversion, Conditionals, Cleft sentences va murakkab gap tuzilmalari bo‘yicha testlar.",
    tag: "Tuzilmalar & Qoidalar",
    icon: IconGrammar,
    color: "purple",
    href: "/content/grammar",
  },
  {
    title: "Mock Tests",
    desc: "IELTS kompyuter formatiga mos mini-testlar, avtomatik ball hisoblagich.",
    tag: "Vaqt bilan amaliyot",
    icon: IconClock,
    color: "ink",
    href: "/practice",
  },
  {
    title: "CEFR Placement",
    desc: "12 ta savolli diagnostika orqali darajangizni (A1–C2) bepul aniqlash testi.",
    tag: "Darajani aniqlash",
    icon: IconTarget,
    color: "coral",
    href: "/assessment",
  },
];

const cefrLevels = [
  { level: "A1", title: "Boshlang‘ich", desc: "Oddiy kundalik iboralar va tanish so‘zlarni tushunish." },
  { level: "A2", title: "Elementar", desc: "Tanish mavzularda sodda muloqot va oddiy matnlar." },
  { level: "B1", title: "O‘rta (Intermediate)", desc: "Mustaqil fikr bildirish, sayohat va ish mavzulari." },
  { level: "B2", title: "Yuqori O‘rta", desc: "Murakkab mavzularni tushunish va ravon muloqot." },
  { level: "C1", title: "Ilg‘or (Advanced)", desc: "Tilni akademik va professional sohada moslashuvchan qo‘llash." },
  { level: "C2", title: "Mukammal (Proficient)", desc: "Ona tili darajasida erkin, chuqur va aniq ifodalash." },
];

const faqList = [
  {
    q: "Platformadan foydalanish bepulmi?",
    a: "Ha! Ro‘yxatdan o‘tish, CEFR diagnostika testi, IELTS Reading mashqlari, Writing tekshiruv vositalari va asosiy darslar bepul taqdim etiladi.",
  },
  {
    q: "Test va essay natijalarim saqlanadimi?",
    a: "Albatta. Hisobingizga kirgan holda topshirgan har bir mini-test va Writing topshirig‘i to‘g‘ridan-to‘g‘ri Firebase bazasida shaxsiy profilingizga biriktirib saqlanadi.",
  },
  {
    q: "IELTS va CEFR o‘rtasida qanday farq bor?",
    a: "IELTS asosan xalqaro universitetlar va immigratsiya uchun (0-9 ball shkalasi), CEFR esa Yevropa umumiy til standarti (A1-C2 darajalari). Ro‘yxatdan o‘tishda qaysi yo‘nalish sizga kerakligini tanlaysiz.",
  },
  {
    q: "Jonli darslarda kimlar qatnashishi mumkin?",
    a: "Ro‘yxatdan o‘tgan barcha talabalar 'Jonli darslar' bo‘limi orqali rejalashtirilgan ochiq vebinarlar va dars yozuvlariga kirishlari mumkin.",
  },
];

function TeacherCard({ teacher }) {
  const [imageAvailable, setImageAvailable] = useState(Boolean(teacher.photo_url));

  return (
    <article className="teacher-card">
      <div className="teacher-photo">
        {imageAvailable ? (
          <img
            src={teacher.photo_url}
            alt={`${teacher.name} ustozning rasmi`}
            onError={() => setImageAvailable(false)}
          />
        ) : (
          <span className="teacher-photo-fallback" aria-hidden="true">
            {teacher.name?.trim().charAt(0) || "U"}
          </span>
        )}
      </div>
      <div>
        <h3>{teacher.name}</h3>
        <span className="gold-badge">★ IELTS Band 9.0</span>
        <p className="teacher-exp">{teacher.experience_years} yil tajriba</p>
        {teacher.bio ? <p className="teacher-bio">{teacher.bio}</p> : null}
      </div>
    </article>
  );
}

export default function HomePage() {
  const [teachers, setTeachers] = useState([]);
  const [teachersLoading, setTeachersLoading] = useState(true);
  const [teachersError, setTeachersError] = useState("");
  const [openFaq, setOpenFaq] = useState(null);

  async function loadTeachers() {
    setTeachersLoading(true);
    setTeachersError("");
    try {
      const items = await getPublishedBandNineTeachers();
      setTeachers(items);
    } catch (error) {
      setTeachersError(error.message || "Ustozlar ro‘yxatini yuklab bo‘lmadi.");
    } finally {
      setTeachersLoading(false);
    }
  }

  useEffect(() => {
    loadTeachers();
  }, []);

  const repeatedTeachers =
    teachers.length > 0 && teachers.length < 4
      ? [...teachers, ...teachers, ...teachers, ...teachers].slice(0, 8)
      : teachers;

  return (
    <>
      {/* HERO SECTION */}
      <section className="container hero" id="top">
        <div className="hero-copy">
          <span className="hero-pill">
            <span className="live-pulse" /> O‘zbekistondagi Zamonaviy IELTS + CEFR Platformasi
          </span>
          <h1>
            Ingliz tilidagi <br />
            <span className="gradient-text">eng yuqori marrangiz.</span>
          </h1>
          <p>
            Maqsadli IELTS 7.5+ yoki CEFR C1 darajasiga erishish uchun individual o‘quv rejasi, interaktiv mashqlar va real vaqtli tahlil tizimi.
          </p>

          <div className="hero-actions">
            <Link className="button" href="/login?mode=register">
              Bepul boshlash <span aria-hidden="true">↗</span>
            </Link>
            <Link className="button button-secondary" href="/assessment">
              <IconTarget size={18} /> Darajangizni aniqlash
            </Link>
          </div>

          <div className="hero-proof-strip">
            <div className="proof-item">
              <strong>4 Ko‘nikma</strong>
              <span>Listening, Reading, Writing, Speaking</span>
            </div>
            <div className="proof-divider" />
            <div className="proof-item">
              <strong>A1 — C2</strong>
              <span>To‘liq CEFR dasturi</span>
            </div>
            <div className="proof-divider" />
            <div className="proof-item">
              <strong>9.0 Band</strong>
              <span>Sertifikatlangan metodika</span>
            </div>
          </div>
        </div>

        {/* HERO 3D GLASS */}
        <div className="goal-wrap hg-stage" aria-label="VELMORA o‘quv kabineti">
          <div className="hg-orbit" aria-hidden="true" />
          <div className="hg-sphere" aria-hidden="true"><div><b>IELTS</b><span>BAND 5.5 → 9.0</span></div></div>
          {[
            ["hg-c1", "#22d3ee", "M4 14v-2a8 8 0 0116 0v2M3 14h4v6H3zM17 14h4v6h-4z"],
            ["hg-c2", "#fbbf24", "M4 20l1-4L16 5l3 3L8 19z"],
            ["hg-c3", "#f472b6", "M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.5 6.7 19.4l1.2-6L3.4 9.3l6-.7z"],
            ["hg-c4", "#34d399", "M12 3a3 3 0 013 3v5a3 3 0 01-6 0V6a3 3 0 013-3zM5 11a7 7 0 0014 0M12 18v3"],
          ].map(([cls, tint, path]) => (
            <span key={cls} className={`hg-cube ${cls}`} style={{ "--t": tint }} aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={path} /></svg>
            </span>
          ))}
          <div className="hg-card">
            <small>SIZNING KABINETINGIZ</small>
            <h3>Maqsadingizni belgilang</h3>
            <p>Ro‘yxatdan o‘tib onboardingni tugating, real natijalaringiz shu yerda chiqadi.</p>
            {[["Reading", "#a78bfa"], ["Listening", "#22d3ee"], ["Writing", "#fbbf24"], ["Speaking", "#34d399"]].map(([name, c]) => (
              <div className="hg-bar" key={name}>
                <span><i style={{ background: c, boxShadow: `0 0 10px ${c}` }} />{name}</span>
                <div style={{ boxShadow: `0 0 0 1px ${c}55` }} />
              </div>
            ))}
            <div className="hg-empty">✦ Birinchi mashqdan keyin progress shu yerda jonlanadi.</div>
          </div>
          <div className="hg-pillars" aria-label="CEFR darajalari A1 dan C2 gacha">
            {["A1", "A2", "B1", "B2", "C1", "C2"].map((l, i) => (
              <div key={l} className={l === "B2" ? "on" : ""} style={{ height: 56 + i * 30, "--c": ["#34d399", "#2dd4bf", "#38bdf8", "#a78bfa", "#f472b6", "#fb923c"][i], "--d": `${i * 0.18}s` }}>{l}</div>
            ))}
          </div>
        </div>
      </section>

      {/* LEARNING MODULES GRID */}
      <section className="section container learning-section" id="learning">
        <div className="section-heading">
          <span className="section-kicker">Har bir ko‘nikmaga alohida yondashuv</span>
          <h2>Imtihonga tayyorgarlik uchun kerakli hamma narsa.</h2>
          <p>Har bir bo‘limda maxsus interaktiv vositalar, lug‘atlar va video tahlillar mavjud.</p>
        </div>

        <div className="learning-grid">
          {learningAreas.map((area) => {
            const Icon = area.icon;
            return (
              <Link className="glass-card learning-card" href={area.href} key={area.title}>
                <div className="card-top-row">
                  <span className={`learning-icon icon-${area.color}`} aria-hidden="true">
                    <Icon size={22} />
                  </span>
                  <span className="learning-tag">{area.tag}</span>
                </div>
                <h3>{area.title}</h3>
                <p>{area.desc}</p>
                <span className="learning-link">
                  Bo‘limni ochish <IconArrowRight size={16} />
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* CEFR LEVELS SECTION */}
      <section className="section container cefr-section" id="cefr">
        <div className="cefr-intro">
          <span className="section-kicker">Xalqaro standartlar</span>
          <h2>A1 dan C2 gacha CEFR darajalari.</h2>
          <p>
            O‘z bilim darajangizni aniq biling. Qisqa diagnostik testimiz sizning hozirgi grammatika va lug‘at ko‘rsatkichlaringizni baholab beradi.
          </p>
          <div className="cefr-cta-row">
            <Link className="button" href="/assessment">
              <IconTarget size={18} /> Diagnostik testni topshirish
            </Link>
          </div>
        </div>

        <div className="cefr-grid">
          {cefrLevels.map((lvl) => (
            <div className="cefr-level" key={lvl.level}>
              <span className="cefr-badge">{lvl.level}</span>
              <div>
                <strong>{lvl.title}</strong>
                <p>{lvl.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PARTNER / OFFICIAL INFO */}
      <section className="partner-section container" aria-labelledby="partners-title">
        <p className="partner-caption" id="partners-title">
          IELTS bo‘yicha rasmiy ma’lumot manbalari va ko‘rsatmalar
        </p>
        <div className="partner-row">
          <a className="partner-card" href="https://ielts.idp.com/" target="_blank" rel="noreferrer">
            <span className="partner-initial partner-idp" aria-hidden="true">IDP</span>
            <span>
              <strong>IDP IELTS</strong>
              <small>Rasmiy imtihon sanalari va talablari</small>
            </span>
            <span className="partner-arrow" aria-hidden="true">↗</span>
          </a>
          <a className="partner-card" href="https://www.britishcouncil.uz/en/exam/ielts" target="_blank" rel="noreferrer">
            <span className="partner-initial partner-bc" aria-hidden="true">BC</span>
            <span>
              <strong>British Council</strong>
              <small>O‘zbekistondagi rasmiy imtihon markazi</small>
            </span>
            <span className="partner-arrow" aria-hidden="true">↗</span>
          </a>
        </div>
      </section>

      {/* FEATURES SECTION */}
      <section className="section container" id="features">
        <div className="section-heading">
          <span className="section-kicker">Platforma imkoniyatlari</span>
          <h2>Nima uchun aynan VELMORA?</h2>
          <p>Biz faqat quruq qoidalar emas, balki real natijaga yo‘naltirilgan zamonaviy ta’lim tajribasini yaratamiz.</p>
        </div>

        <div className="feature-grid">
          {features.map((feat) => (
            <article className="glass-card feature-card" key={feat.num}>
              <span className="feature-num">{feat.num}</span>
              <h3>{feat.title}</h3>
              <p>{feat.desc}</p>
            </article>
          ))}
        </div>
      </section>

      {/* TEACHERS SECTION */}
      <section className="section container" id="teachers">
        <div className="section-heading">
          <span className="section-kicker">Tajribali mutaxassislar</span>
          <h2>IELTS Band 9.0 Ustozlar jamoasi</h2>
          <p>Ko‘p yillik xalqaro tajribaga ega bo‘lgan yetakchi instruktorlarimiz.</p>
        </div>

        {teachersLoading ? <LoadingState label="Ustozlar profili yuklanmoqda..." /> : null}
        {teachersError ? <ErrorState message={teachersError} onRetry={loadTeachers} /> : null}

        {!teachersLoading && !teachersError && teachers.length === 0 ? (
          <div className="hg-empty-block">
            <h3>Ustozlar tez orada qo‘shiladi</h3>
            <p>Tasdiqlangan ustozlar profili Firestore bazasidan avtomatik shu yerda chiqadi.</p>
          </div>
        ) : null}

        {!teachersLoading && !teachersError && teachers.length > 0 ? (
          <div className="teacher-marquee">
            <div className="teacher-track">
              {repeatedTeachers.map((teacher, index) => (
                <TeacherCard key={`${teacher.id}-${index}`} teacher={teacher} />
              ))}
            </div>
          </div>
        ) : null}
      </section>

      {/* FAQ SECTION */}
      <section className="section container" id="faq">
        <div className="section-heading">
          <span className="section-kicker">Savollaringiz bormi?</span>
          <h2>Ko‘p so‘raladigan savollar</h2>
          <p>O‘quvchilarimiz tomonidan eng ko‘p beriladigan savollarga aniq javoblar.</p>
        </div>

        <div className="faq-grid">
          {faqList.map((item, idx) => (
            <div
              className={`glass-card faq-card ${openFaq === idx ? "faq-card-open" : ""}`}
              key={idx}
              onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
            >
              <div className="faq-header">
                <h3>{item.q}</h3>
                <span className="faq-icon">{openFaq === idx ? "−" : "+"}</span>
              </div>
              {openFaq === idx && <p className="faq-answer">{item.a}</p>}
            </div>
          ))}
        </div>
      </section>

      {/* FINAL CALL TO ACTION */}
      <section className="section container closing-section" id="results">
        <div className="closing-banner">
          <div>
            <span className="section-kicker">Muvaffaqiyat bugun boshlanadi</span>
            <h2>Keyingi sertifikatingiz tomon ilk qadamni tashlang.</h2>
            <p>Hisob oching, o‘quv yo‘nalishingizni tanlang va bazada saqlanadigan individual mashqlarni boshlang.</p>
          </div>
          <Link className="button button-light" href="/login?mode=register">
            Bepul hisob yaratish <IconArrowRight size={18} />
          </Link>
        </div>
      </section>
    </>
  );
}
