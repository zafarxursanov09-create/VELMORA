"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { createPracticeResult } from "@/lib/api/progress";
import { updateProfileSettings } from "@/lib/api/profile";
import { useProfile } from "@/lib/useProfile";
import {
  IconTarget,
  IconCheckCircle,
  IconSparkles,
  IconRefresh,
  IconArrowRight,
  IconAward,
} from "@/components/Icons";

const questions = [
  { skill: "Grammar", prompt: "My sister ___ to university by bus every morning.", options: ["go", "goes", "is go", "going"], answer: 1, explanation: "With he, she or it in the present simple, add -s/es to the verb." },
  { skill: "Vocabulary", prompt: "The word “reliable” is closest in meaning to…", options: ["easy to trust", "very expensive", "difficult to find", "quick to change"], answer: 0, explanation: "A reliable person or thing can be trusted to work well consistently." },
  { skill: "Grammar", prompt: "We ___ the museum last Saturday, but it was closed.", options: ["visit", "have visited", "visited", "are visiting"], answer: 2, explanation: "A finished action at a specific past time uses past simple." },
  { skill: "Reading", prompt: "Mina cycles to work when the weather is dry. On rainy days, she takes the train. How does Mina travel on a rainy day?", options: ["By bicycle", "By train", "On foot", "By car"], answer: 1, explanation: "The passage explicitly states Mina takes the train when it rains." },
  { skill: "Grammar", prompt: "If I ___ more free time, I would take a photography course.", options: ["have", "will have", "had", "would have"], answer: 2, explanation: "Hypothetical present conditions require 'if' + past simple, followed by 'would' + base verb." },
  { skill: "Vocabulary", prompt: "The new library is considerably larger than the old one. What does “considerably” mean here?", options: ["slightly", "by a large amount", "unexpectedly", "for a short time"], answer: 1, explanation: "Considerably means by a notably large extent or degree." },
  { skill: "Reading", prompt: "A study found that people remembered more after taking short breaks. The researchers did not say how long the breaks should be. Which statement is supported?", options: ["Long breaks always improve memory", "Short breaks may support recall", "Breaks should last exactly ten minutes", "The researchers tested every age group"], answer: 1, explanation: "The passage supports a possible benefit of short breaks, with no fixed duration specified." },
  { skill: "Grammar", prompt: "By the time the guests arrived, we ___ dinner.", options: ["finished", "have finished", "had finished", "are finishing"], answer: 2, explanation: "Past perfect marks the earlier of two consecutive past events." },
  { skill: "Vocabulary", prompt: "Although the proposal was initially rejected, the committee later reconsidered it. “Initially” means…", options: ["at first", "in secret", "by mistake", "in the end"], answer: 0, explanation: "Initially means at the beginning or onset of an event." },
  { skill: "Reading", prompt: "The town introduced a parking fee downtown. Bus use rose slightly, but the report noted that a new bus route opened in the same month. What is the fairest conclusion?", options: ["The fee alone caused more bus use", "The new route alone caused more bus use", "Both changes may have influenced bus use", "Bus use did not change"], answer: 2, explanation: "Because two variables occurred simultaneously, causation cannot be attributed solely to the fee." },
  { skill: "Grammar", prompt: "Rarely ___ such a detailed account of the expedition.", options: ["we have read", "have we read", "we read have", "did we have read"], answer: 1, explanation: "Fronted negative adverbs (Rarely, Seldom) require subject-auxiliary inversion." },
  { skill: "Vocabulary", prompt: "The findings are tentative because the sample was small. “Tentative” most nearly means…", options: ["widely accepted", "not yet certain", "carefully hidden", "clearly mistaken"], answer: 1, explanation: "Tentative describes an initial conclusion that is provisional and not yet definitive." },
];

const levels = ["A1", "A2", "B1", "B2", "C1", "C2"];

const levelDescriptions = {
  A1: { title: "A1 Boshlang‘ich", desc: "Siz sodda kundalik so‘z va iboralarni tushunasiz. Til asoslarini mustahkamlash tavsiya etiladi." },
  A2: { title: "A2 Elementar", desc: "Tanish mavzularda oddiy muloqot qila olasiz. Lug‘at boyligini oshirish va grammatikani chuqurlashtirish kerak." },
  B1: { title: "B1 O‘rta (Intermediate)", desc: "Kundalik mavzularda mustaqil fikr yuritasiz. Murakkab matnlarni o‘qishga o‘tish vaqti keldi." },
  B2: { title: "B2 Yuqori O‘rta (Upper-Intermediate)", desc: "IELTS 6.0–6.5 ekvivalenti. Ravon muloqot va murakkab g‘oyalarni ifodalashga qodirsiz." },
  C1: { title: "C1 Ilg‘or (Advanced)", desc: "IELTS 7.0–8.0 ekvivalenti. Akademik matnlarni chuqur tushunib, boy so‘z zaxirasidan moslashuvchan foydalanasiz." },
  C2: { title: "C2 Mukammal (Proficient)", desc: "IELTS 8.5–9.0 ekvivalenti. Deyarli barcha murakkab matn va nutqni osonlik bilan anglaysiz." },
};

function levelForScore(score) {
  if (score <= 1) return "A1";
  if (score <= 3) return "A2";
  if (score <= 5) return "B1";
  if (score <= 7) return "B2";
  if (score <= 9) return "C1";
  return "C2";
}

export default function AssessmentPage() {
  const { user, profile } = useProfile({ requireAuth: false });
  const startedAt = useRef(Date.now());
  const [answers, setAnswers] = useState({});
  const [current, setCurrent] = useState(0);
  const [result, setResult] = useState(null);
  const [saveState, setSaveState] = useState("idle");
  const [saveError, setSaveError] = useState("");
  const [appliedToProfile, setAppliedToProfile] = useState(false);

  function finishAssessment() {
    const correct = questions.reduce(
      (total, q, index) => total + (answers[index] === q.answer ? 1 : 0),
      0
    );
    const level = levelForScore(correct);
    const skills = ["Grammar", "Vocabulary", "Reading"].map((skill) => {
      const related = questions.filter((q) => q.skill === skill);
      const score = related.filter((q) => answers[questions.indexOf(q)] === q.answer).length;
      return { name: skill, score, total: related.length };
    });

    setResult({ correct, level, skills });

    if (user) {
      setSaveState("saving");
      createPracticeResult(user.uid, {
        examKey: "cefr-placement-v1",
        skill: "cefr",
        score: correct,
        total: questions.length,
        accuracy: Math.round((correct / questions.length) * 100),
        durationSeconds: Math.round((Date.now() - startedAt.current) / 1000),
      })
        .then(() => setSaveState("saved"))
        .catch((err) => {
          setSaveError(err.message || "Natijani saqlab bo‘lmadi.");
          setSaveState("failed");
        });
    } else {
      setSaveState("guest");
    }
  }

  async function applyLevelToProfile() {
    if (!user || !profile || !result) return;
    try {
      await updateProfileSettings(user.uid, {
        gender: profile.gender || "prefer_not_to_say",
        age: profile.age || 20,
        track: profile.track || "cefr",
        targetLevel: profile.target_level || "C1",
        currentLevel: result.level,
        examDate: profile.exam_date || new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10),
        studyMinutes: profile.study_minutes || 60,
        weakSkills: profile.weak_skills || ["Reading"],
      });
      setAppliedToProfile(true);
    } catch (err) {
      setSaveError(err.message || "Profilga yangilashda xatolik yuz berdi.");
    }
  }

  if (result) {
    const levelMeta = levelDescriptions[result.level] || levelDescriptions.B2;

    return (
      <section className="container page-wrap assessment-page">
        <span className="section-kicker">Diagnostika Yakunlandi</span>
        <h1 className="page-title">Sizning CEFR Natijangiz</h1>

        {/* Certificate / Scorecard */}
        <div className="assessment-result glass-card">
          <div className="result-level">
            <span className="cert-watermark">CEFR</span>
            <span className="cert-subtitle">Aniqlangan daraja</span>
            <strong className="cert-badge">{result.level}</strong>
            <small>
              {result.correct} / {questions.length} to‘g‘ri javob ({Math.round((result.correct / questions.length) * 100)}%)
            </small>
          </div>

          <div className="result-detail">
            <h3>{levelMeta.title}</h3>
            <p className="level-desc">{levelMeta.desc}</p>

            <div className="skills-bar-breakdown">
              <h4>Ko‘nikmalar bo‘yicha tahlil:</h4>
              {result.skills.map((skill) => (
                <div className="result-skill-row" key={skill.name}>
                  <div>
                    <span>{skill.name}</span>
                    <strong>{skill.score} / {skill.total}</strong>
                  </div>
                  <span className="progress-track">
                    <span style={{ width: `${(skill.score / skill.total) * 100}%` }} />
                  </span>
                </div>
              ))}
            </div>

            {user && profile && (
              <div className="profile-sync-box">
                {appliedToProfile ? (
                  <span className="notice notice-success">
                    ✓ Profilingizdagi hozirgi daraja {result.level} ga muvaffaqiyatli o‘zgartirildi!
                  </span>
                ) : (
                  <button
                    type="button"
                    className="button button-small"
                    onClick={applyLevelToProfile}
                  >
                    <IconTarget size={18} /> Ushbu darajani profilingizga biriktirish
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Answers and Explanations Accordion */}
        <details className="assessment-review glass-card">
          <summary>Savollar, javoblar va izohlarni ko‘rish ▾</summary>
          <div className="review-questions-list">
            {questions.map((item, index) => {
              const isCorrect = answers[index] === item.answer;
              return (
                <article className="review-item" key={item.prompt}>
                  <div className="review-head">
                    <span className="badge-purple">{item.skill}</span>
                    <span className={isCorrect ? "text-success" : "text-warn"}>
                      {isCorrect ? "✓ To‘g‘ri" : "✕ Noto‘g‘ri"}
                    </span>
                  </div>
                  <h4>{item.prompt}</h4>
                  <p className="user-answer-line">
                    Sizning javobingiz: <b>{item.options[answers[index]]}</b>
                    {!isCorrect && (
                      <span> · To‘g‘ri javob: <b>{item.options[item.answer]}</b></span>
                    )}
                  </p>
                  <p className="explanation-text">{item.explanation}</p>
                </article>
              );
            })}
          </div>
        </details>

        <div className="assessment-actions">
          <Link className="button" href={user ? "/dashboard" : "/login?mode=register"}>
            {user ? "Kabinetingizga qaytish →" : "Hisob ochib o‘qishni boshlash →"}
          </Link>
          <button
            className="button button-secondary"
            type="button"
            onClick={() => {
              startedAt.current = Date.now();
              setAnswers({});
              setCurrent(0);
              setSaveError("");
              setSaveState("idle");
              setResult(null);
            }}
          >
            <IconRefresh size={18} /> Testni qayta topshirish
          </button>
        </div>
      </section>
    );
  }

  const question = questions[current];
  const answeredCount = Object.keys(answers).length;

  return (
    <section className="container page-wrap assessment-page">
      <Link className="text-link content-back" href="/#cefr">
        ← Bosh sahifaga qaytish
      </Link>

      <div className="assessment-hero-head">
        <span className="section-kicker">Diagnostik Baholash</span>
        <h1 className="page-title">CEFR Darajasini Aniqlash Testi</h1>
        <p className="page-intro">
          12 ta savol orqali sizning grammatika, lug‘at va o‘qish ko‘nikmalaringizni tezkor baholaymiz.
        </p>
      </div>

      <div className="assessment-progress-wrapper glass-card">
        <div className="progress-labels">
          <span>Jarayon:</span>
          <strong>{answeredCount} / {questions.length} ta savol yechildi</strong>
        </div>
        <div className="progress-track">
          <span style={{ width: `${(answeredCount / questions.length) * 100}%` }} />
        </div>
      </div>

      {/* Question Card */}
      <div className="assessment-question glass-card">
        <div className="question-meta">
          <span className="badge-purple">{question.skill}</span>
          <span>Savol {current + 1} / {questions.length}</span>
        </div>

        <h2 className="assessment-prompt">{question.prompt}</h2>

        <div className="answer-options-grid">
          {question.options.map((option, index) => {
            const isSelected = answers[current] === index;
            return (
              <button
                key={option}
                type="button"
                className={`answer-option-btn ${isSelected ? "selected" : ""}`}
                onClick={() => setAnswers((prev) => ({ ...prev, [current]: index }))}
              >
                <span className="opt-letter">{String.fromCharCode(65 + index)}</span>
                <span className="opt-text">{option}</span>
              </button>
            );
          })}
        </div>

        <div className="question-controls">
          <button
            type="button"
            className="button button-quiet"
            disabled={current === 0}
            onClick={() => setCurrent((v) => v - 1)}
          >
            ← Oldingi
          </button>

          {current < questions.length - 1 ? (
            <button
              type="button"
              className="button button-secondary"
              onClick={() => setCurrent((v) => v + 1)}
            >
              Keyingi →
            </button>
          ) : (
            <button
              type="button"
              className="button"
              disabled={answeredCount !== questions.length}
              onClick={finishAssessment}
            >
              Natijani ko‘rish <IconArrowRight size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Question Navigator Palette */}
      <nav className="question-nav" aria-label="Savol tanlash">
        {questions.map((_, index) => (
          <button
            key={index}
            type="button"
            className={`q-step-btn ${current === index ? "current" : ""} ${
              answers[index] !== undefined ? "answered" : ""
            }`}
            onClick={() => setCurrent(index)}
          >
            {index + 1}
          </button>
        ))}
      </nav>
    </section>
  );
}