"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ErrorState, Badge } from "@/components/UI";
import { createPracticeResult } from "@/lib/api/progress";
import { useProfile } from "@/lib/useProfile";
import {
  IconClock,
  IconCheckCircle,
  IconSparkles,
  IconArrowRight,
  IconRefresh,
  IconBook,
  IconAward,
} from "@/components/Icons";

const testBank = [
  {
    id: "ielts-reading-mini-v1",
    title: "Test 1: Urban Green Spaces and Community Gardens",
    level: "Band 6.0 — 7.5",
    duration: 20 * 60,
    passage: `In many cities, community gardens have transformed unused plots into productive green spaces. Residents share responsibility for planting, watering, and maintaining the land. While the gardens produce vegetables and herbs, their value extends beyond food. Neighbours who might otherwise never meet often exchange skills and practical advice. Some gardens run workshops for children, teaching them how soil, insects, and weather affect plant growth.

Researchers have also observed that regular contact with green spaces can encourage people to spend more time outdoors, fostering mental well-being and reducing urban stress. However, community gardens are not a replacement for large public parks: most are small, and access may depend on a local group’s membership rules.

The projects also require reliable volunteers and sustained financial resources. During unusually dry summers, water costs can rise significantly, and a garden may need emergency support from the local municipality. Successful groups therefore agree clear responsibilities and make long-term plans before they begin planting.`,
    questions: [
      { prompt: "What do residents share in a community garden?", options: ["The cost of buying land", "Responsibility for looking after the plot", "Ownership of nearby homes", "Transport to the garden"], answer: 1, explanation: "The passage directly says residents share planting, watering and maintenance of the land." },
      { prompt: "According to the passage, what is one benefit beyond producing food?", options: ["It guarantees lower food prices", "It brings neighbours together", "It replaces local schools", "It provides full-time jobs"], answer: 1, explanation: "Neighbours exchange skills and advice and have a chance to meet." },
      { prompt: "What can children learn in some garden workshops?", options: ["How to design city roads", "How plants are affected by nature", "How to sell vegetables online", "How to build a public park"], answer: 1, explanation: "Workshops explain the effects of soil, insects and weather on plant growth." },
      { prompt: "The passage suggests contact with green spaces may encourage people to…", options: ["spend more time outside", "move to the countryside", "eat only home-grown food", "avoid community activities"], answer: 0, explanation: "Researchers observed that green-space contact may increase time spent outdoors." },
      { prompt: "Why are gardens not a substitute for large public parks?", options: ["They cannot grow herbs", "They are usually small and may restrict access", "They are closed in the summer", "They do not have volunteers"], answer: 1, explanation: "The passage notes that most are small and access can depend on membership rules." },
      { prompt: "What challenge can unusually dry summers create?", options: ["Higher water costs", "Too many workshops", "Fewer insects", "A shortage of land"], answer: 0, explanation: "The passage directly states that water costs can rise in dry summers." },
      { prompt: "What does the passage say successful groups should do before planting?", options: ["Hire full-time gardeners", "Agree responsibilities and plan ahead", "Close the garden to children", "Build a new public park"], answer: 1, explanation: "The final sentence recommends clear responsibilities and long-term plans." },
      { prompt: "Which statement is supported by the passage?", options: ["Every city garden is open to everyone", "Gardens can provide learning opportunities", "Councils always pay water bills", "Gardens produce food all year"], answer: 1, explanation: "Some gardens run educational workshops for children." },
      { prompt: "In the passage, “their value extends beyond food” means the gardens…", options: ["offer benefits in addition to crops", "are too expensive to maintain", "are mainly used for research", "should become public parks"], answer: 0, explanation: "The text describes social and educational benefits beyond producing food." },
      { prompt: "What is the writer’s main purpose?", options: ["To argue that parks should be closed", "To describe benefits and practical challenges of community gardens", "To explain how to grow one specific vegetable", "To compare farming in different countries"], answer: 1, explanation: "The passage presents both the benefits and the planning challenges of community gardens." },
    ],
  },
  {
    id: "ielts-reading-mini-v2",
    title: "Test 2: Cognitive Neuroscience & Bilingualism",
    level: "Band 7.0 — 8.5",
    duration: 20 * 60,
    passage: `For decades, psychologists warned that raising children bilingually might hinder their linguistic development, causing confusion between vocabulary systems. Recent advances in neuroimaging, however, have largely dispelled this notion. Studies demonstrate that individuals who actively juggle two languages possess enhanced executive function—the cognitive control mechanism that manages focus, task-switching, and problem-solving.

When bilinguals speak, both linguistic systems remain subtly activated in the prefrontal cortex. To produce an utterance in English, a bilingual must continuously suppress equivalent Russian or Uzbek expressions. This habitual mental gymnastics strengthens neural pathways, creating a phenomenon termed 'cognitive reserve'.

Remarkably, epidemiological research reveals that bilingual adults exhibit symptoms of neurodegenerative disorders, such as Alzheimer’s disease, four to five years later than their monolingual counterparts with equivalent brain pathology. While bilingualism does not prevent underlying neural deterioration, it equips the brain to compensate through alternative pathways, reinforcing lifelong cognitive resilience.`,
    questions: [
      { prompt: "What historical belief about bilingualism does the passage mention?", options: ["It caused immediate neurological disease", "It could impede linguistic development", "It was only possible for adults", "It improved mathematical ability"], answer: 1, explanation: "The opening sentence notes psychologists historically warned that bilingualism might hinder language development." },
      { prompt: "What enabled researchers to reconsider older views on bilingualism?", options: ["New neuroimaging technologies", "Global population censuses", "Surveys of translation agencies", "Children’s school exam results"], answer: 0, explanation: "Recent advances in neuroimaging dispelled the older misconception." },
      { prompt: "What is 'executive function' defined as?", options: ["The ability to speak without accent", "The cognitive mechanism managing focus and task-switching", "Memorization of multiple dictionaries", "Physical coordination of vocal cords"], answer: 1, explanation: "The text explicitly defines executive function as managing focus, task-switching, and problem-solving." },
      { prompt: "What occurs in the brain when a bilingual speaks one language?", options: ["The other language is permanently erased", "Both language systems remain subtly activated", "Only vocabulary from childhood is accessible", "Brain metabolism drops significantly"], answer: 1, explanation: "The text states that both linguistic systems remain subtly activated in the prefrontal cortex." },
      { prompt: "How does suppressing the non-target language benefit the speaker?", options: ["It prevents them from speaking quickly", "It strengthens neural control pathways", "It makes learning a third language impossible", "It eliminates emotional feelings"], answer: 1, explanation: "The mental gymnastics of suppressing non-target words strengthens neural pathways." },
      { prompt: "What does the term 'cognitive reserve' refer to in this context?", options: ["Stored vocabulary lists", "Enhanced brain resilience against decline", "Financial savings in linguistic research", "A backup memory center"], answer: 1, explanation: "Cognitive reserve allows the brain to withstand damage and maintain function." },
      { prompt: "How does bilingualism impact the onset of Alzheimer’s symptoms?", options: ["Symptoms appear four to five years later", "It completely cures the disease", "It speeds up symptom manifestation", "It has no observable effect on timing"], answer: 0, explanation: "Epidemiological research reveals bilinguals show symptoms 4 to 5 years later." },
      { prompt: "Does bilingualism prevent the physical pathology of brain degeneration?", options: ["Yes, brain cells never die", "No, but it helps the brain compensate", "Only if acquired in infancy", "Researchers have reached no conclusion"], answer: 1, explanation: "The passage notes it does not prevent underlying deterioration, but equips the brain to compensate." },
      { prompt: "What is the primary role of the prefrontal cortex mentioned here?", options: ["Regulating heart rate", "Managing language selection and suppression", "Storing visual memories of faces", "Filtering background auditory noise"], answer: 1, explanation: "The text highlights prefrontal cortex activation during language suppression and executive control." },
      { prompt: "Which best summarizes the passage’s overall tone?", options: ["Skeptical and warning", "Scientific and appreciative", "Indifferent and historical", "Critical and dismissive"], answer: 1, explanation: "The author presents rigorous neuroscience findings demonstrating significant benefits." },
    ],
  },
];

function calculateIeltsBand(score, total) {
  const percentage = (score / total) * 100;
  if (percentage === 100) return "9.0";
  if (percentage >= 90) return "8.5";
  if (percentage >= 80) return "7.5";
  if (percentage >= 70) return "7.0";
  if (percentage >= 60) return "6.5";
  if (percentage >= 50) return "6.0";
  if (percentage >= 40) return "5.5";
  return "5.0";
}

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const remainder = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${remainder}`;
}

export default function PracticePage() {
  const { user } = useProfile({ requireAuth: false });
  const [selectedTestIndex, setSelectedTestIndex] = useState(0);
  const currentTest = testBank[selectedTestIndex];

  const [answers, setAnswers] = useState({});
  const [flagged, setFlagged] = useState([]);
  const [current, setCurrent] = useState(0);
  const [remaining, setRemaining] = useState(currentTest.duration);
  const [fontSize, setFontSize] = useState("normal"); // normal, large
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [result, setResult] = useState(null);
  const [saveState, setSaveState] = useState("idle");
  const [saveError, setSaveError] = useState("");

  // Reset when test changes
  function switchTest(index) {
    setSelectedTestIndex(index);
    setAnswers({});
    setFlagged([]);
    setCurrent(0);
    setRemaining(testBank[index].duration);
    setResult(null);
    setSaveState("idle");
    setSaveError("");
  }

  useEffect(() => {
    if (result) return undefined;
    const timer = setInterval(() => setRemaining((seconds) => Math.max(0, seconds - 1)), 1000);
    return () => clearInterval(timer);
  }, [result]);

  const submitTest = useCallback(() => {
    if (result) return;
    const score = currentTest.questions.reduce(
      (total, q, index) => total + (answers[index] === q.answer ? 1 : 0),
      0
    );
    const band = calculateIeltsBand(score, currentTest.questions.length);
    const submittedResult = {
      score,
      total: currentTest.questions.length,
      accuracy: Math.round((score / currentTest.questions.length) * 100),
      durationSeconds: currentTest.duration - remaining,
      examKey: currentTest.id,
      skill: "reading",
      band,
    };
    setResult(submittedResult);
    setConfirmOpen(false);

    if (!user) {
      setSaveState("guest");
      return;
    }

    setSaveState("saving");
    createPracticeResult(user.uid, submittedResult)
      .then(() => setSaveState("saved"))
      .catch((error) => {
        setSaveError(error.message || "Natijani saqlab bo‘lmadi.");
        setSaveState("failed");
      });
  }, [answers, currentTest, remaining, result, user]);

  useEffect(() => {
    if (remaining === 0 && !result) submitTest();
  }, [remaining, result, submitTest]);

  function toggleFlag(index) {
    setFlagged((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  }

  return (
    <section className="container page-wrap">
      {/* PRACTICE TOP BAR */}
      <div className="practice-header glass-card">
        <div className="practice-header-left">
          <Link href="/dashboard" className="text-link">
            ← Dashboard
          </Link>
          <div className="test-selector-tabs">
            {testBank.map((t, idx) => (
              <button
                key={t.id}
                type="button"
                className={`test-tab-btn ${selectedTestIndex === idx ? "active" : ""}`}
                onClick={() => switchTest(idx)}
              >
                {t.title.split(":")[0]}
              </button>
            ))}
          </div>
        </div>

        <div className="practice-header-controls">
          <div className="font-size-control">
            <span>Matn o‘lchami:</span>
            <button
              type="button"
              className={fontSize === "normal" ? "active" : ""}
              onClick={() => setFontSize("normal")}
            >
              A
            </button>
            <button
              type="button"
              className={fontSize === "large" ? "active" : ""}
              onClick={() => setFontSize("large")}
            >
              A+
            </button>
          </div>

          <div className={`practice-timer ${remaining < 300 ? "timer-warning" : ""}`}>
            <IconClock size={18} />
            <strong>{formatTime(remaining)}</strong>
          </div>

          {!result && (
            <button
              type="button"
              className="button button-small"
              onClick={() => setConfirmOpen(true)}
            >
              Testni topshirish
            </button>
          )}
        </div>
      </div>

      {saveError ? <ErrorState message={saveError} /> : null}

      {/* CONFIRMATION MODAL */}
      {confirmOpen && (
        <div className="modal-overlay" onClick={() => setConfirmOpen(false)}>
          <div className="modal-dialog glass-card" onClick={(e) => e.stopPropagation()}>
            <h3>Testni yakunlaysizmi?</h3>
            <p>
              Siz {Object.keys(answers).length} / {currentTest.questions.length} ta savolga javob berdingiz.
              {flagged.length > 0 && ` ${flagged.length} ta savol belgilab qo‘yilgan.`}
            </p>
            <div className="modal-actions">
              <button
                type="button"
                className="button button-quiet"
                onClick={() => setConfirmOpen(false)}
              >
                Davom ettirish
              </button>
              <button type="button" className="button" onClick={submitTest}>
                Ha, topshirish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RESULT CARD IF SUBMITTED */}
      {result && (
        <div className="practice-result-banner glass-card">
          <div className="result-score-block">
            <span className="result-kicker">IELTS READING NATIJASI</span>
            <div className="band-display">
              <h2>Band {result.band}</h2>
              <span className="score-sub">
                {result.score} / {result.total} to‘g‘ri ({result.accuracy}%)
              </span>
            </div>
          </div>

          <div className="result-meta-block">
            <div>
              <span>Sarflangan vaqt:</span>
              <strong>{formatTime(result.durationSeconds)}</strong>
            </div>
            <div>
              <span>Firebase holati:</span>
              <strong>
                {saveState === "saving" && "Bazaga saqlanmoqda..."}
                {saveState === "saved" && "✓ Profilingizga saqlandi"}
                {saveState === "guest" && "Tizimga kirilmagan (mehmon)"}
                {saveState === "failed" && "Saqlashda xatolik"}
              </strong>
            </div>
            <button
              type="button"
              className="button button-small button-secondary"
              onClick={() => switchTest(selectedTestIndex)}
            >
              <IconRefresh size={16} /> Qayta ishlash
            </button>
          </div>
        </div>
      )}

      {/* COMPUTER-DELIVERED IELTS SPLIT SCREEN */}
      <div className="practice-split-layout">
        {/* LEFT PANE: PASSAGE */}
        <div className={`practice-passage-pane glass-card font-${fontSize}`}>
          <div className="passage-pane-header">
            <span className="badge-purple">IELTS Reading Passage</span>
            <h3>{currentTest.title}</h3>
          </div>
          <div className="passage-body">
            {currentTest.passage.split("\n\n").map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </div>
        </div>

        {/* RIGHT PANE: QUESTIONS */}
        <div className="practice-questions-pane glass-card">
          {/* Question navigation grid */}
          <div className="question-nav-strip">
            <span>Savollar:</span>
            <div className="question-palette">
              {currentTest.questions.map((_, idx) => {
                const isAnswered = answers[idx] !== undefined;
                const isFlagged = flagged.includes(idx);
                const isCurrent = current === idx;
                return (
                  <button
                    key={idx}
                    type="button"
                    className={`pal-btn ${isCurrent ? "active" : ""} ${
                      isAnswered ? "answered" : ""
                    } ${isFlagged ? "flagged" : ""}`}
                    onClick={() => setCurrent(idx)}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Question Card */}
          <div className="active-question-card">
            <div className="q-card-top">
              <span className="q-counter">
                Savol {current + 1} / {currentTest.questions.length}
              </span>
              <button
                type="button"
                className={`flag-btn ${flagged.includes(current) ? "active" : ""}`}
                onClick={() => toggleFlag(current)}
              >
                ⚑ {flagged.includes(current) ? "Belgilangan" : "Belgilash"}
              </button>
            </div>

            <h4 className="q-prompt">{currentTest.questions[current].prompt}</h4>

            <div className="q-options-list">
              {currentTest.questions[current].options.map((option, optIdx) => {
                const isChosen = answers[current] === optIdx;
                const isCorrect = result && optIdx === currentTest.questions[current].answer;
                const isIncorrect = result && isChosen && optIdx !== currentTest.questions[current].answer;

                return (
                  <label
                    key={optIdx}
                    className={`q-opt-label ${isChosen ? "chosen" : ""} ${
                      isCorrect ? "correct" : ""
                    } ${isIncorrect ? "incorrect" : ""}`}
                  >
                    <input
                      type="radio"
                      name={`q-${current}`}
                      checked={isChosen}
                      disabled={Boolean(result)}
                      onChange={() => setAnswers({ ...answers, [current]: optIdx })}
                    />
                    <span className="q-marker">{String.fromCharCode(65 + optIdx)}</span>
                    <span className="q-opt-text">{option}</span>
                  </label>
                );
              })}
            </div>

            {/* Explanation when reviewed */}
            {result && (
              <div className="q-explanation-box">
                <strong>Tushuntirish:</strong>
                <p>{currentTest.questions[current].explanation}</p>
              </div>
            )}

            {/* Pagination Controls */}
            <div className="q-controls-bottom">
              <button
                type="button"
                className="button button-small button-quiet"
                disabled={current === 0}
                onClick={() => setCurrent((c) => Math.max(0, c - 1))}
              >
                ← Oldingi
              </button>
              <button
                type="button"
                className="button button-small button-secondary"
                disabled={current === currentTest.questions.length - 1}
                onClick={() => setCurrent((c) => Math.min(currentTest.questions.length - 1, c + 1))}
              >
                Keyingi →
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}