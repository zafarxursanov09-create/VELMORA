"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";
import { ErrorState, LoadingState } from "@/components/UI";
import { getFirebaseServices } from "@/lib/firebase";
import { useProfile } from "@/lib/useProfile";

const genderLabels = { female: "Ayol", male: "Erkak", prefer_not_to_say: "Ko‘rsatilmagan" };
const skillColors = { Reading: "#a78bfa", Listening: "#22d3ee", Writing: "#fbbf24", Speaking: "#34d399" };

function initials(name = "") {
  return name.trim().split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("") || "V";
}

export default function ProfilePage() {
  const router = useRouter();
  const { user, profile, loading, error, refresh } = useProfile({ requireAuth: true, requireOnboarding: true });

  async function handleSignOut() {
    try {
      await signOut(getFirebaseServices().auth);
      router.replace("/");
    } catch {}
  }

  if (loading) return <section className="container section"><LoadingState label="Profil yuklanmoqda..." /></section>;
  if (error) return <section className="container section"><ErrorState message={error} onRetry={refresh} /></section>;
  if (!profile) return <section className="container section"><ErrorState message="Profil topilmadi. Qaytadan kiring." onRetry={refresh} /></section>;

  const name = profile.full_name || user?.displayName || "Foydalanuvchi";
  const isTeacher = profile.role === "teacher";
  const weak = Array.isArray(profile.weak_skills) ? profile.weak_skills : [];
  const empty = (text) => <div className="pf-empty"><b>Hali ma’lumot yo‘q</b>{text}</div>;

  return (
    <section className="container section pf-page">
      <div className="pf-hero">
        <div className="pf-avatar">{initials(name)}</div>
        <div className="pf-who">
          <h1>{name}</h1>
          <p>{profile.email || user?.email}</p>
          <div className="pf-chips">
            <span>{isTeacher ? "Ustoz" : "Talaba"}</span>
            {profile.track ? <span>{profile.track === "ielts" ? "IELTS yo‘nalishi" : "CEFR yo‘nalishi"}</span> : null}
          </div>
        </div>
        <Link className="button" href={isTeacher ? "/teacher" : "/dashboard"}>{isTeacher ? "Ustoz paneli" : "Sozlamalar"}</Link>
      </div>

      <div className="pf-grid">
        <article className="pf-card">
          <h4 style={{ color: "#fbbf24" }}>MAQSAD</h4>
          {profile.target_level ? <div className="pf-big">{profile.target_level}</div> : null}
          <div className="pf-kv"><span>Hozirgi daraja</span><b>{profile.current_level || "—"}</b></div>
          <div className="pf-kv"><span>Imtihon sanasi</span><b>{profile.exam_date || "—"}</b></div>
        </article>

        <article className="pf-card">
          <h4 style={{ color: "#22d3ee" }}>O‘QUV REJASI</h4>
          <div className="pf-kv"><span>Kunlik vaqt</span><b>{profile.study_minutes ? `${profile.study_minutes} daqiqa` : "—"}</b></div>
          <div className="pf-kv"><span>Yosh</span><b>{profile.age || "—"}</b></div>
          <div className="pf-kv"><span>Jins</span><b>{genderLabels[profile.gender] || "—"}</b></div>
          <h4 style={{ color: "#fbbf24", marginTop: 16 }}>ZAIF KO‘NIKMALAR</h4>
          <div className="pf-tags">
            {weak.length ? weak.map((w) => <i key={w} style={{ "--c": skillColors[w] || "#a78bfa" }}>{w}</i>) : <span className="pf-muted">Tanlanmagan</span>}
          </div>
        </article>

        <article className="pf-card">
          <h4 style={{ color: "#f472b6" }}>YUTUQLAR</h4>
          {empty("Birinchi mashqdan keyin yutuqlar shu yerda ochiladi.")}
        </article>

        <article className="pf-card pf-wide">
          <h4 style={{ color: "#34d399" }}>OXIRGI NATIJALAR</h4>
          {empty("Practice yoki Writing bajarganingizda natijalar shu yerda chiqadi.")}
        </article>

        <article className="pf-card">
          <h4 style={{ color: "#c4b5fd" }}>HISOB</h4>
          <Link className="pf-kv" href="/support"><span>Yordam markazi</span><b>→</b></Link>
          <button className="pf-kv pf-out" type="button" onClick={handleSignOut}><span>Chiqish</span><b>→</b></button>
        </article>
      </div>
    </section>
  );
}
