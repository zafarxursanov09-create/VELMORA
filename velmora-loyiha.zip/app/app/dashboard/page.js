"use client";

import Link from "next/link";
import { signOut } from "firebase/auth";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { getFirebaseServices } from "@/lib/firebase";
import { getPracticeResults, getWritingSubmissions } from "@/lib/api/progress";
import { updateProfileSettings } from "@/lib/api/profile";
import { useProfile } from "@/lib/useProfile";
import { ErrorState, LoadingState, Badge } from "@/components/UI";
import {
  IconFlame,
  IconClock,
  IconTarget,
  IconCheckCircle,
  IconSettings,
  IconBook,
  IconHeadphones,
  IconEdit,
  IconMic,
  IconVocabulary,
  IconGrammar,
  IconArrowRight,
  IconBarChart,
  IconAward,
} from "@/components/Icons";

function daysUntil(dateValue) {
  if (!dateValue) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const examDate = new Date(`${dateValue}T00:00:00`);
  return Math.max(0, Math.ceil((examDate.getTime() - today.getTime()) / 86400000));
}

export default function DashboardPage() {
  const router = useRouter();
  const { user, profile, loading, error, refresh: refreshProfile } = useProfile({
    requireAuth: true,
    requireOnboarding: true,
  });

  const [signOutError, setSignOutError] = useState("");
  const [practiceResults, setPracticeResults] = useState([]);
  const [resultsLoading, setResultsLoading] = useState(true);
  const [resultsError, setResultsError] = useState("");
  const [writingSubmissions, setWritingSubmissions] = useState([]);
  const [writingLoading, setWritingLoading] = useState(true);
  const [writingError, setWritingError] = useState("");

  // Goal Settings Modal State
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingTarget, setSettingTarget] = useState("");
  const [settingExamDate, setSettingExamDate] = useState("");
  const [settingMinutes, setSettingMinutes] = useState(60);
  const [settingWeakSkills, setSettingWeakSkills] = useState([]);
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState("");

  // Daily Tasks checked state
  const [dailyCompleted, setDailyCompleted] = useState({
    reading: false,
    vocab: false,
    writing: false,
  });

  useEffect(() => {
    if (profile) {
      setSettingTarget(profile.target_level || "7.0");
      setSettingExamDate(profile.exam_date || "");
      setSettingMinutes(profile.study_minutes || 60);
      setSettingWeakSkills(profile.weak_skills || ["Reading"]);
    }
  }, [profile]);

  useEffect(() => {
    if (loading) return undefined;
    if (!user) {
      setResultsLoading(false);
      return undefined;
    }
    let active = true;
    getPracticeResults(user.uid)
      .then((items) => {
        if (active) setPracticeResults(items);
      })
      .catch((loadError) => {
        if (active) setResultsError(loadError.message || "Test natijalarini yuklab bo‘lmadi.");
      })
      .finally(() => {
        if (active) setResultsLoading(false);
      });
    return () => {
      active = false;
    };
  }, [loading, user]);

  useEffect(() => {
    if (loading) return undefined;
    if (!user) {
      setWritingLoading(false);
      return undefined;
    }
    let active = true;
    getWritingSubmissions(user.uid)
      .then((items) => {
        if (active) setWritingSubmissions(items);
      })
      .catch((loadError) => {
        if (active) setWritingError(loadError.message || "Writing tarixini yuklab bo‘lmadi.");
      })
      .finally(() => {
        if (active) setWritingLoading(false);
      });
    return () => {
      active = false;
    };
  }, [loading, user]);

  if (loading) {
    return (
      <div className="container">
        <LoadingState label="O‘quv kabinetingiz yuklanmoqda..." />
      </div>
    );
  }

  if (error) {
    return (
      <section className="container page-wrap">
        <ErrorState message={error} />
      </section>
    );
  }

  if (!profile) {
    return (
      <section className="container page-wrap">
        <ErrorState message="Profil topilmadi. Tizimdan chiqib, qayta kiring." />
      </section>
    );
  }

  if (profile.role !== "student") {
    return (
      <section className="container page-wrap">
        <h1 className="page-title">Bu sahifa o‘quvchilar uchun.</h1>
        <Link className="button" href={profile.role === "teacher" ? "/teacher" : "/"}>
          O‘z sahifangizga o‘tish
        </Link>
      </section>
    );
  }

  const days = daysUntil(profile.exam_date);
  const trackName = profile.track === "ielts" ? "IELTS" : "CEFR";
  const focusedSkills = Array.isArray(profile.weak_skills) ? profile.weak_skills : [];
  const focusSkill = focusedSkills[0] || "Reading";
  const studyMinutes = Number(profile.study_minutes) || 60;
  const practiceMinutes = Math.max(15, studyMinutes - Math.round(studyMinutes / 3));
  const reviewMinutes = studyMinutes - practiceMinutes;

  const readingResults = practiceResults.filter((r) => r.skill === "reading");
  const cefrResults = practiceResults.filter((r) => r.skill === "cefr");
  const averageAccuracy = readingResults.length
    ? Math.round(readingResults.reduce((acc, r) => acc + r.accuracy, 0) / readingResults.length)
    : null;

  async function handleSignOut() {
    setSignOutError("");
    try {
      const { auth } = getFirebaseServices();
      await signOut(auth);
      router.replace("/");
    } catch (signOutErr) {
      setSignOutError(signOutErr.message || "Tizimdan chiqishda xatolik yuz berdi.");
    }
  }

  async function handleSaveSettings(e) {
    e.preventDefault();
    setSavingSettings(true);
    setSettingsSuccess("");
    try {
      await updateProfileSettings(user.uid, {
        gender: profile.gender || "prefer_not_to_say",
        age: profile.age || 20,
        track: profile.track || "ielts",
        targetLevel: settingTarget,
        currentLevel: profile.current_level || "B2",
        examDate: settingExamDate,
        studyMinutes: Number(settingMinutes),
        weakSkills: settingWeakSkills.length ? settingWeakSkills : ["Reading"],
      });
      setSettingsSuccess("Sozlamalar yangilandi!");
      if (refreshProfile) refreshProfile();
      setTimeout(() => {
        setSettingsOpen(false);
        setSettingsSuccess("");
      }, 1000);
    } catch (err) {
      alert("Xatolik: " + (err.message || "Saqlab bo‘lmadi"));
    } finally {
      setSavingSettings(false);
    }
  }

  const sectionsList = [
    { title: "Reading", icon: IconBook, desc: "Matnni o‘qish, tahlil qilish va savol turlari.", href: "/practice" },
    { title: "Listening", icon: IconHeadphones, desc: "Audio materiallar va tushunish darslari.", href: "/content/listening" },
    { title: "Writing", icon: IconEdit, desc: "Task 1 va Task 2 insho simulyatori.", href: "/writing" },
    { title: "Speaking", icon: IconMic, desc: "Nutq ravonligi, Cue Card va ovoz yozish.", href: "/content/speaking" },
    { title: "Vocabulary", icon: IconVocabulary, desc: "Interaktiv kartalar va talaffuz audiosi.", href: "/content/vocabulary" },
    { title: "Grammar", icon: IconGrammar, desc: "Inversiya, shart mayli va murakkab gaplar.", href: "/content/grammar" },
  ];

  return (
    <section className="container page-wrap">
      {signOutError ? <ErrorState message={signOutError} /> : null}

      {/* DASHBOARD HEADER */}
      <div className="dashboard-head glass-card">
        <div className="dash-user-welcome">
          <div className="user-avatar-badge">
            {(profile.full_name || user.email || "V").trim().charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="dash-pill-row">
              <span className="section-kicker">Shaxsiy O‘quv Kabinetingiz</span>
              <span className="streak-badge">
                <IconFlame size={16} /> 4 kunlik seriya
              </span>
            </div>
            <h1 className="page-title">Xush kelibsiz, {profile.full_name || user?.email}!</h1>
            <p className="page-intro">
              Bugungi o‘qish maqsadingiz: <strong>{studyMinutes} daqiqa</strong> faol mashg‘ulot.
            </p>
          </div>
        </div>

        <div className="dashboard-actions">
          {days !== null && (
            <div className="exam-countdown glass-card">
              <strong>{days}</strong>
              <span>kun imtihongacha</span>
            </div>
          )}
          <button
            className="button button-secondary button-small"
            type="button"
            onClick={() => setSettingsOpen(true)}
          >
            <IconSettings size={18} /> Sozlamalar
          </button>
          <button className="button button-quiet button-small" type="button" onClick={handleSignOut}>
            Chiqish
          </button>
        </div>
      </div>

      {/* SETTINGS MODAL */}
      {settingsOpen && (
        <div className="modal-overlay" onClick={() => setSettingsOpen(false)}>
          <div className="modal-dialog glass-card settings-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <h3>O‘quv Maqsadlari & Sozlamalar</h3>
              <button
                type="button"
                className="close-modal-btn"
                onClick={() => setSettingsOpen(false)}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveSettings} className="settings-form">
              <label className="form-field">
                Maqsadli Daraja / Band:
                <select
                  value={settingTarget}
                  onChange={(e) => setSettingTarget(e.target.value)}
                >
                  {profile.track === "ielts" ? (
                    ["6.0", "6.5", "7.0", "7.5", "8.0", "8.5", "9.0"].map((b) => (
                      <option key={b} value={b}>Band {b}</option>
                    ))
                  ) : (
                    ["B1", "B2", "C1", "C2"].map((lvl) => (
                      <option key={lvl} value={lvl}>{lvl}</option>
                    ))
                  )}
                </select>
              </label>

              <label className="form-field">
                Imtihon Sanasi:
                <input
                  type="date"
                  value={settingExamDate}
                  min={new Date().toISOString().slice(0, 10)}
                  onChange={(e) => setSettingExamDate(e.target.value)}
                />
              </label>

              <label className="form-field">
                Kunlik O‘qish Vaqti:
                <select
                  value={settingMinutes}
                  onChange={(e) => setSettingMinutes(Number(e.target.value))}
                >
                  <option value={30}>30 daqiqa / kun</option>
                  <option value={60}>60 daqiqa / kun</option>
                  <option value={90}>90 daqiqa / kun</option>
                  <option value={120}>120 daqiqa / kun</option>
                </select>
              </label>

              {settingsSuccess ? <div className="notice notice-success">{settingsSuccess}</div> : null}

              <div className="modal-actions">
                <button
                  type="button"
                  className="button button-quiet"
                  onClick={() => setSettingsOpen(false)}
                >
                  Bekor qilish
                </button>
                <button type="submit" className="button" disabled={savingSettings}>
                  {savingSettings ? "Saqlanmoqda..." : "O‘zgarishlarni saqlash"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STATS OVERVIEW CARDS */}
      <div className="dashboard-grid dashboard-overview">
        <article className="glass-card dashboard-card">
          <span className="dashboard-icon icon-purple">
            <IconTarget size={22} />
          </span>
          <span className="section-kicker">Yo‘nalish & Maqsad</span>
          <h2>
            {trackName} {profile.target_level ? `· ${profile.target_level}` : ""}
          </h2>
          <p>Hozirgi daraja: {profile.current_level || "B2"}</p>
        </article>

        <article className="glass-card dashboard-card">
          <span className="dashboard-icon icon-teal">
            <IconClock size={22} />
          </span>
          <span className="section-kicker">Kunlik Reja</span>
          <h2>{studyMinutes} daqiqa</h2>
          <p>Har kuni maqsad sari kichik qadam.</p>
        </article>

        <article className="glass-card dashboard-card">
          <span className="dashboard-icon icon-gold">
            <IconBarChart size={22} />
          </span>
          <span className="section-kicker">O‘rtacha Aniqlik</span>
          <h2>{resultsLoading ? "…" : averageAccuracy === null ? "—" : `${averageAccuracy}%`}</h2>
          <p>{readingResults.length} ta topshirilgan mini-test.</p>
        </article>

        <article className="glass-card dashboard-card">
          <span className="dashboard-icon icon-coral">
            <IconAward size={22} />
          </span>
          <span className="section-kicker">Insholar Soni</span>
          <h2>{writingLoading ? "…" : writingSubmissions.length} ta</h2>
          <p>Writing lab’da yozilgan ishlar.</p>
        </article>
      </div>

      {/* TODAY'S INTERACTIVE ACTION CHECKLIST */}
      <section className="dashboard-plan glass-card" aria-labelledby="today-plan-title">
        <div className="plan-heading">
          <div>
            <span className="section-kicker">Bugungi individual rejangiz</span>
            <h2 id="today-plan-title">Bugun bajarilishi kerak bo‘lgan vazifalar</h2>
          </div>
          <span className="plan-total">{studyMinutes} daqiqa jami</span>
        </div>

        <div className="plan-items">
          <div className="plan-item-interactive">
            <input
              type="checkbox"
              id="task-focus"
              checked={dailyCompleted.reading}
              onChange={() =>
                setDailyCompleted((prev) => ({ ...prev, reading: !prev.reading }))
              }
            />
            <label htmlFor="task-focus">
              <strong>{focusSkill} mashg‘uloti ({practiceMinutes} daq.)</strong>
              <small>Asosiy diqqat markazidagi ko‘nikma ustida ishlash</small>
            </label>
            <Link
              className="button button-small button-secondary"
              href={focusSkill === "Writing" ? "/writing" : "/practice"}
            >
              Boshlash →
            </Link>
          </div>

          <div className="plan-item-interactive">
            <input
              type="checkbox"
              id="task-vocab"
              checked={dailyCompleted.vocab}
              onChange={() =>
                setDailyCompleted((prev) => ({ ...prev, vocab: !prev.vocab }))
              }
            />
            <label htmlFor="task-vocab">
              <strong>10 ta yangi akademik so‘z ({reviewMinutes} daq.)</strong>
              <small>Flashcards orqali so‘z boyligini mustahkamlash</small>
            </label>
            <Link
              className="button button-small button-secondary"
              href="/content/vocabulary"
            >
              Lug‘at →
            </Link>
          </div>
        </div>
      </section>

      {/* LEARNING MODULES GRID */}
      <div className="section-heading dashboard-section-heading">
        <span className="section-kicker">O‘quv Modullari</span>
        <h2>Qaysi bo‘lim ustida ishlaymiz?</h2>
      </div>

      <div className="dashboard-grid">
        {sectionsList.map((sec) => {
          const Icon = sec.icon;
          return (
            <Link className="glass-card dashboard-card dashboard-link" href={sec.href} key={sec.title}>
              <span className="dashboard-icon">
                <Icon size={24} />
              </span>
              <h3>{sec.title}</h3>
              <p>{sec.desc}</p>
              <span className="text-link">Ochish →</span>
            </Link>
          );
        })}
      </div>

      {/* RECENT ACTIVITY LOGS */}
      <div className="dashboard-history-row">
        {/* Practice results */}
        <section className="glass-card dashboard-activity-col">
          <div className="history-col-head">
            <span className="section-kicker">Test Natijalari</span>
            <h3>Oxirgi topshirilgan testlar</h3>
          </div>
          {resultsLoading ? (
            <p>Yuklanmoqda...</p>
          ) : practiceResults.length === 0 ? (
            <p>Hali natijalar yo‘q. Reading mini-testdan boshlang.</p>
          ) : (
            <div className="dashboard-result-list">
              {practiceResults.slice(0, 4).map((r) => (
                <article className="dashboard-result-row" key={r.id}>
                  <strong>
                    {r.skill === "cefr" ? "CEFR Diagnostika" : "Reading Mini-test"} · {r.score} / {r.total}
                  </strong>
                  <span className="badge-purple">{r.accuracy}% aniqlik</span>
                  <time dateTime={r.created_at}>
                    {new Date(r.created_at).toLocaleDateString("uz-UZ")}
                  </time>
                </article>
              ))}
            </div>
          )}
          <Link className="text-link" href="/practice">
            Yangi test topshirish →
          </Link>
        </section>

        {/* Writing submissions */}
        <section className="glass-card dashboard-activity-col">
          <div className="history-col-head">
            <span className="section-kicker">Writing Tarixi</span>
            <h3>Oxirgi yozilgan insholar</h3>
          </div>
          {writingLoading ? (
            <p>Yuklanmoqda...</p>
          ) : writingSubmissions.length === 0 ? (
            <p>Hali essay saqlanmagan. Writing lab’da birinchi inshongizni yozing.</p>
          ) : (
            <div className="dashboard-result-list">
              {writingSubmissions.slice(0, 4).map((s) => (
                <article className="dashboard-result-row" key={s.id}>
                  <strong>{s.prompt_title}</strong>
                  <span className="badge-gold">{s.word_count} so‘z</span>
                  <time dateTime={s.created_at}>
                    {new Date(s.created_at).toLocaleDateString("uz-UZ")}
                  </time>
                </article>
              ))}
            </div>
          )}
          <Link className="text-link" href="/writing">
            Writing Lab’ga o‘tish →
          </Link>
        </section>
      </div>
    </section>
  );
}
