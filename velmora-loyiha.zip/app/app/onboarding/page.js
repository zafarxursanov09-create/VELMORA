"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { saveOnboarding } from "@/lib/api/profile";
import { Button, ErrorState, LoadingState } from "@/components/UI";
import { useProfile } from "@/lib/useProfile";

const cefrLevels = ["A1", "A2", "B1", "B2", "C1", "C2"];
const ieltsLevels = ["5.5", "6.0", "6.5", "7.0", "7.5", "8.0", "8.5", "9.0"];
const skills = ["Listening", "Reading", "Writing", "Speaking"];

export default function OnboardingPage() {
  const router = useRouter();
  const { user, profile, loading, error: profileError } = useProfile({
    requireAuth: true,
    requireOnboarding: true,
    redirectOnboarded: true,
  });
  const [gender, setGender] = useState("");
  const [age, setAge] = useState("");
  const [track, setTrack] = useState("");
  const [targetLevel, setTargetLevel] = useState("");
  const [currentLevel, setCurrentLevel] = useState("");
  const [examDate, setExamDate] = useState("");
  const [studyMinutes, setStudyMinutes] = useState("60");
  const [weakSkills, setWeakSkills] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const minimumDate = new Date().toISOString().slice(0, 10);
  const levels = track === "ielts" ? ieltsLevels : cefrLevels;

  function changeTrack(value) {
    setTrack(value);
    setTargetLevel("");
  }

  function toggleWeakSkill(skill) {
    setWeakSkills((current) => current.includes(skill)
      ? current.filter((item) => item !== skill)
      : [...current, skill]);
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");
    if (!user || !profile) {
      setError("Profil ma’lumoti yuklanmadi. Sahifani qayta yuklang.");
      return;
    }
    if (!gender || !age || !track || !targetLevel || !currentLevel || !examDate || weakSkills.length === 0) {
      setError("Davom etish uchun barcha maydonlarni to‘ldiring.");
      return;
    }
    if (Number(age) < 1 || Number(age) > 120) {
      setError("Yosh 1 dan 120 gacha bo‘lishi kerak.");
      return;
    }
    if (examDate < minimumDate) {
      setError("Imtihon sanasi bugun yoki undan keyingi sana bo‘lishi kerak.");
      return;
    }

    setBusy(true);
    try {
      await saveOnboarding(user.uid, { gender, age, track, targetLevel, currentLevel, examDate, studyMinutes, weakSkills });
      router.replace("/dashboard");
    } catch (saveError) {
      setError(saveError.message || "Ma’lumotlarni saqlab bo‘lmadi. Qayta urinib ko‘ring.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <div className="container"><LoadingState label="Profil tekshirilmoqda..." /></div>;
  if (profileError) return <div className="container page-wrap"><ErrorState message={profileError} /></div>;

  return (
    <section className="container page-wrap">
      <span className="section-kicker">Birinchi qadam</span>
      <h1 className="page-title">O‘quv rejangizni sozlang</h1>
      <p className="page-intro">Maqsadingiz, hozirgi darajangiz va o‘qish vaqtingizni belgilang. VELMORA sizga mos materiallarni ajratib beradi.</p>
      <form className="glass-card auth-form onboarding-form" onSubmit={handleSubmit}>
        <div className="form-grid">
          <label className="form-field">
            Jins
            <select required value={gender} onChange={(event) => setGender(event.target.value)}>
              <option value="">Tanlang</option>
              <option value="female">Ayol</option>
              <option value="male">Erkak</option>
              <option value="prefer_not_to_say">Javob bermaslik</option>
            </select>
          </label>
          <label className="form-field">
            Yosh
            <input type="number" min="1" max="120" required value={age} onChange={(event) => setAge(event.target.value)} />
          </label>
          <label className="form-field">
            O‘qish yo‘nalishi
            <select required value={track} onChange={(event) => changeTrack(event.target.value)}>
              <option value="">Tanlang</option>
              <option value="ielts">IELTS</option>
              <option value="cefr">CEFR</option>
            </select>
          </label>
          <label className="form-field">
            Maqsadli {track === "ielts" ? "IELTS bandi" : track === "cefr" ? "CEFR darajasi" : "daraja"}
            <select required value={targetLevel} onChange={(event) => setTargetLevel(event.target.value)} disabled={!track}>
              <option value="">Tanlang</option>
              {levels.map((level) => <option key={level} value={level}>{track === "ielts" ? `Band ${level}` : level}</option>)}
            </select>
          </label>
          <label className="form-field">
            Hozirgi ingliz tili darajangiz
            <select required value={currentLevel} onChange={(event) => setCurrentLevel(event.target.value)}>
              <option value="">Taxminiy darajangizni tanlang</option>
              {cefrLevels.map((level) => <option key={level} value={level}>{level}</option>)}
            </select>
          </label>
          <label className="form-field">
            Imtihon sanasi
            <input type="date" min={minimumDate} required value={examDate} onChange={(event) => setExamDate(event.target.value)} />
          </label>
          <label className="form-field">
            Kuniga ajratadigan vaqtingiz
            <select value={studyMinutes} onChange={(event) => setStudyMinutes(event.target.value)}>
              <option value="30">30 daqiqa</option><option value="60">1 soat</option><option value="90">1,5 soat</option><option value="120">2 soat yoki ko‘proq</option>
            </select>
          </label>
        </div>
        <fieldset className="skill-preferences">
          <legend>Ko‘proq mashq qilmoqchi bo‘lgan ko‘nikmalaringiz</legend>
          <div className="skill-options">{skills.map((skill) => <label key={skill}><input type="checkbox" checked={weakSkills.includes(skill)} onChange={() => toggleWeakSkill(skill)} /><span>{skill}</span></label>)}</div>
        </fieldset>
        {error ? <ErrorState message={error} /> : null}
        <Button type="submit" disabled={busy}>{busy ? "Saqlanmoqda..." : "Davom etish"}</Button>
      </form>
    </section>
  );
}
