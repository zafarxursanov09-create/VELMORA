function fallbackAnswer(message) {
  const text = message.toLowerCase();
  if (/login|sign in|kir|parol|password|reset/.test(text)) {
    return "Hisobga kirish: Kirish sahifasida email va parolni kiriting. Parol esdan chiqqan bo‘lsa, ‘Parolni unutdingizmi?’ tugmasidan foydalaning. Google orqali kirish ham mavjud.";
  }
  if (/register|sign up|ro.yxat|account|hisob/.test(text)) {
    return "Hisob yaratish: ‘Boshlash’ni bosing, o‘quvchi yoki ustoz turini tanlang va email orqali ro‘yxatdan o‘ting. O‘quvchi hisobida keyin maqsad va darajani belgilang.";
  }
  if (/cefr|level|daraja|assessment|test/.test(text)) {
    return "CEFR darajani aniqlash: CEFR bo‘limidagi qisqa diagnostik testni ishlang. Natija taxminiy bo‘lib, rasmiy sertifikat hisoblanmaydi.";
  }
  if (/writing|essay|yozuv|insho|feedback/.test(text)) {
    return "Writing bo‘limida Task 2 essay yozib, hajm, paragraflar, bog‘lovchilar va takrorlar bo‘yicha checklist olishingiz mumkin. Bu hozircha AI yoki rasmiy IELTS bahosi emas.";
  }
  if (/class|lesson|live|dars|video|record/.test(text)) {
    return "Jonli darslar sahifasida e’lon qilingan kelgusi mashg‘ulotlar va video yozuvlar chiqadi. O‘qituvchilar o‘z panelidan dars havolasini e’lon qilishlari mumkin.";
  }
  if (/payment|premium|to.lov|narx/.test(text)) {
    return "Premium to‘lovlari hozircha platformaga ulanmagan. To‘lov havolasi yoki karta ma’lumotlarini yubormang; yordam markaziga murojaat qiling.";
  }
  return "Sizga yordam berishga tayyorman. Kirish, ro‘yxatdan o‘tish, CEFR testi, Writing, jonli darslar yoki natijalar haqida so‘rashingiz mumkin. Murakkab masala bo‘lsa, ‘Yordam markazi’ orqali jamoaga yozing.";
}

function allowedOrigins() {
  const configured = process.env.ASSISTANT_ALLOWED_ORIGINS;
  if (configured) return configured.split(",").map((origin) => origin.trim()).filter(Boolean);
  if (process.env.NODE_ENV !== "production") return ["http://localhost:5500", "http://127.0.0.1:5500"];
  return [];
}

function corsHeaders(request) {
  const origin = request.headers.get("origin");
  const headers = new Headers({ Vary: "Origin" });
  if (origin && allowedOrigins().includes(origin)) {
    headers.set("Access-Control-Allow-Origin", origin);
    headers.set("Access-Control-Allow-Methods", "POST, OPTIONS");
    headers.set("Access-Control-Allow-Headers", "Content-Type");
  }
  return headers;
}

function json(request, payload, status = 200) {
  return Response.json(payload, { status, headers: corsHeaders(request) });
}

export async function OPTIONS(request) {
  return new Response(null, { status: 204, headers: corsHeaders(request) });
}

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json(request, { error: "So‘rov formati noto‘g‘ri." }, 400);
  }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message || message.length > 1500) {
    return json(request, { error: "Xabar 1–1500 belgi oralig‘ida bo‘lishi kerak." }, 400);
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json(request, { reply: fallbackAnswer(message), mode: "faq" });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 18000);
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        temperature: 0.3,
        max_tokens: 350,
        messages: [
          { role: "system", content: "You are VELMORA's concise 24/7 support assistant for an IELTS and CEFR learning platform. Reply in the user's language (Uzbek or English), in 2-4 short sentences. Help with login, learning paths, CEFR diagnostics, writing checklist, live classes and navigation. Never claim a diagnostic is an official certificate or a heuristic checklist is AI IELTS scoring. Never request passwords, payment card data or verification codes. For account-specific or billing issues, direct users to the support centre." },
          { role: "user", content: message },
        ],
      }),
      signal: controller.signal,
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) return json(request, { error: "AI yordamchi hozir javob bera olmadi. Yordam markaziga murojaat qiling." }, 502);
    const reply = result.choices?.[0]?.message?.content?.trim();
    if (!reply) return json(request, { error: "AI yordamchidan bo‘sh javob keldi." }, 502);
    return json(request, { reply, mode: "ai" });
  } catch {
    return json(request, { error: "AI yordamchi bilan aloqa uzildi. Birozdan so‘ng qayta urinib ko‘ring." }, 502);
  } finally {
    clearTimeout(timeout);
  }
}