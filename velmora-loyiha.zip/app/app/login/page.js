"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from "firebase/auth";
import { createProfile, getProfile } from "@/lib/api/profile";
import { Button, ErrorState, LoadingState } from "@/components/UI";
import { checkFirebaseConnection, getFirebaseConfig, getFirebaseServices } from "@/lib/firebase";

function getAuthErrorMessage(error) {
  const messages = {
    "auth/email-already-in-use": "Bu elektron pochta bilan hisob allaqachon mavjud. Tizimga kiring.",
    "auth/invalid-credential": "Elektron pochta yoki parol noto‘g‘ri.",
    "auth/invalid-email": "Elektron pochta manzili noto‘g‘ri.",
    "auth/weak-password": "Parol kamida 6 ta belgidan iborat bo‘lishi kerak.",
    "auth/network-request-failed": "Internet yoki Firebase ulanishida muammo. Ulanishni tekshirib, qayta urinib ko‘ring.",
    "auth/operation-not-allowed": "Email/parol orqali kirish Firebase Console’da yoqilmagan.",
    "auth/popup-closed-by-user": "Google orqali kirish oynasi yopildi.",
    "auth/popup-blocked": "Brauzer kirish oynasini blokladi. Qalqib chiquvchi oynalarga ruxsat bering.",
    "auth/unauthorized-domain": "Sayt domeni Firebase Console’dagi ruxsat berilgan domenlarga qo‘shilmagan.",
  };
  return messages[error.code] || error.message || "Kirishda xatolik yuz berdi.";
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [mode, setMode] = useState(searchParams.get("mode") === "register" ? "register" : "login");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [connection, setConnection] = useState(null);
  const [authReady, setAuthReady] = useState(false);

  useEffect(() => {
    setMode(searchParams.get("mode") === "register" ? "register" : "login");
  }, [searchParams]);

  function goToProfile(profile) {
    if (profile.role === "student" && !profile.onboarded) {
      router.replace("/onboarding");
    } else {
      router.replace(profile.role === "admin" ? "/admin" : profile.role === "teacher" ? "/teacher" : "/dashboard");
    }
  }

  async function ensureProfile(user, preferredName) {
    let profile = await getProfile(user.uid);
    if (!profile) {
      profile = await createProfile(user, preferredName || user.displayName || "");
    }
    return profile;
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setMessage("");

    try {
      const { auth } = getFirebaseServices();
      if (mode === "register") {
        const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (fullName.trim()) {
          await updateProfile(credential.user, { displayName: fullName.trim() });
        }
        const profile = await createProfile(credential.user, fullName.trim());
        goToProfile(profile);
      } else {
        const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
        const profile = await ensureProfile(credential.user, "");
        goToProfile(profile);
      }
    } catch (authError) {
      setError(getAuthErrorMessage(authError));
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const { auth, googleProvider } = getFirebaseServices();
      if (mode === "register") {
        window.localStorage.setItem("velmora_signup_name", fullName.trim());
      }
      const credential = await signInWithPopup(auth, googleProvider);
      const selectedName = window.localStorage.getItem("velmora_signup_name");
      const profile = await ensureProfile(credential.user, selectedName || fullName.trim());
      window.localStorage.removeItem("velmora_signup_name");
      goToProfile(profile);
    } catch (oauthError) {
      if (oauthError.code === "auth/operation-not-allowed") {
        setError("Google orqali kirish yoqilmagan. Firebase Console → Authentication → Sign-in method bo‘limida Google provayderini yoqing.");
      } else {
        setError(getAuthErrorMessage(oauthError));
      }
    } finally {
      setBusy(false);
    }
  }

  async function handleConnectionCheck() {
    setConnection({ loading: true, message: "" });
    const result = await checkFirebaseConnection();
    setConnection({ loading: false, ...result });
  }

  async function handlePasswordReset() {
    setError("");
    setMessage("");
    if (!email.trim()) {
      setError("Parolni tiklash uchun avval elektron pochtangizni kiriting.");
      return;
    }
    setBusy(true);
    try {
      const { auth } = getFirebaseServices();
      await sendPasswordResetEmail(auth, email.trim());
      setMessage("Agar bu manzil ro‘yxatdan o‘tgan bo‘lsa, parolni tiklash xati yuborildi.");
    } catch (resetError) {
      setError(getAuthErrorMessage(resetError));
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    const config = getFirebaseConfig();
    if (config.error) {
      setError(config.error);
      setAuthReady(true);
      return undefined;
    }

    const { auth } = getFirebaseServices();
    return onAuthStateChanged(auth, async (user) => {
      setAuthReady(true);
      if (!user) return;
      try {
        const profile = await getProfile(user.uid);
        if (profile) goToProfile(profile);
      } catch (profileError) {
        setError(getAuthErrorMessage(profileError));
      }
    });
  }, []);

  if (!authReady) return <div className="container"><LoadingState label="Kirish sahifasi yuklanmoqda..." /></div>;

  return (
    <div className="container auth-layout">
      <section className="auth-promo">
        <span className="section-kicker">VELMORA platformasi</span>
        <h1>Bilimingizga sarmoya kiriting.</h1>
        <p>IELTS yoki CEFR maqsadingiz uchun o‘zingizga mos o‘quv yo‘lini boshlang.</p>
        <div className="auth-benefits">
          <span>IELTS va CEFR uchun alohida ta’lim yo‘nalishlari</span>
          <span>Talaba va ustozlar uchun maxsus hisoblar</span>
          <span>O‘z sur’atingizda o‘rganish imkoniyati</span>
        </div>
      </section>
      <section className="auth-form-wrap">
        <span className="section-kicker">Xush kelibsiz</span>
        <h2>{mode === "login" ? "Hisobingizga kiring" : "Hisob yarating"}</h2>
        <p>{mode === "login" ? "Davom etish uchun ma’lumotlaringizni kiriting." : "Ro‘yxatdan o‘tish uchun maydonlarni to‘ldiring."}</p>
        <div className="mode-switch" aria-label="Kirish yoki ro‘yxatdan o‘tish">
          <button type="button" aria-pressed={mode === "login"} onClick={() => { setMode("login"); setError(""); setMessage(""); }}>Kirish</button>
          <button type="button" aria-pressed={mode === "register"} onClick={() => { setMode("register"); setError(""); setMessage(""); }}>Ro‘yxatdan o‘tish</button>
        </div>
        {mode === "register" ? (
          <p className="form-note">Ro‘yxatdan o‘tish o‘quvchilar uchun. Ustoz hisobi administrator tomonidan faollashtiriladi.</p>
        ) : null}
        <form className="auth-form" onSubmit={handleSubmit}>
          {mode === "register" ? (
            <label className="form-field">
              Ism va familiya
              <input autoComplete="name" required value={fullName} onChange={(event) => setFullName(event.target.value)} />
            </label>
          ) : null}
          <label className="form-field">
            Elektron pochta
            <input type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} />
          </label>
          <label className="form-field" htmlFor="auth-password">Parol</label>
          <div className="password-control"><input id="auth-password" type={showPassword ? "text" : "password"} autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={6} required value={password} onChange={(event) => setPassword(event.target.value)} /><button className="password-toggle" type="button" aria-label={showPassword ? "Parolni yashirish" : "Parolni ko‘rsatish"} onClick={() => setShowPassword((visible) => !visible)}>{showPassword ? "Yashirish" : "Ko‘rsatish"}</button></div>
          {mode === "login" ? <button className="password-reset" type="button" onClick={handlePasswordReset} disabled={busy}>Parolni unutdingizmi?</button> : null}
          {error ? <ErrorState message={error} /> : null}
          {message ? <div className="notice notice-success" role="status">{message}</div> : null}
          <Button type="submit" disabled={busy}>{busy ? "Biroz kuting..." : mode === "login" ? "Kirish" : "Hisob yaratish"}</Button>
        </form>
        <div className="divider">yoki</div>
        <Button className="button-secondary" type="button" disabled={busy} onClick={handleGoogle}>
          <span className="google-icon" aria-hidden="true">G</span> Google bilan davom etish
        </Button>
        <details className="auth-diagnostics"><summary>Texnik yordam</summary><button className="password-reset" type="button" onClick={handleConnectionCheck} disabled={connection?.loading}>{connection?.loading ? "Ulanish tekshirilmoqda..." : "Firebase ulanishini tekshirish"}</button>{connection && !connection.loading ? <div className={`notice ${connection.ok ? "notice-success" : "notice-error"}`} role="status">{connection.message}</div> : null}</details>
      </section>
    </div>
  );
}

export default function LoginPage() {
  return <Suspense fallback={<LoadingState />}><LoginForm /></Suspense>;
}
