import "./globals.css";
import "./glass.css";
import { BgPicker } from "@/components/BgPicker";
import { Footer, Navbar, SupportFab } from "@/components/SiteChrome";
import { LiveBackground } from "@/components/UI";

export const metadata = {
  title: "VELMORA | IELTS va CEFR platformasi",
  description: "IELTS va CEFR maqsadingizga mos darslar, o'quv yo'nalishlari va materiallar.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="uz" data-theme="dark" data-bg="aurora" suppressHydrationWarning>
      <head>
        {/* Inline script: runs before CSS paint — prevents flash of wrong theme */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var d=document.documentElement,t=localStorage.getItem('velmora_theme'),b=localStorage.getItem('velmora_bg');d.setAttribute('data-theme',t==='light'?'light':'dark');d.setAttribute('data-bg',b||'aurora');}catch(e){}})();`,
          }}
        />
      </head>
      <body>
        <LiveBackground />
        <Navbar />
        <main className="site-main">{children}</main>
        <Footer />
        <SupportFab />
        <BgPicker />
      </body>
    </html>
  );
}
