"use client";

import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { ErrorState, LoadingState } from "@/components/UI";

export default function TeacherPage() {
  const { profile, loading, error } = useProfile({ requireAuth: true });

  if (loading) return <div className="container"><LoadingState label="Ustoz profilingiz yuklanmoqda..." /></div>;
  if (error) return <section className="container page-wrap"><ErrorState message={error} /></section>;
  if (!profile) return <section className="container page-wrap"><ErrorState message="Profil topilmadi. Qayta tizimga kiring." /></section>;

  if (profile.role !== "teacher") {
    return (
      <section className="container page-wrap">
        <h1 className="page-title">Bu sahifa ustozlar uchun.</h1>
        <Link className="button" href="/dashboard">O‘quv kabinetiga o‘tish</Link>
      </section>
    );
  }

  return (
    <section className="container page-wrap">
      <span className="section-kicker">Ustozlar uchun</span>
      <h1 className="page-title">Xush kelibsiz, {profile.full_name || "ustoz"}!</h1>
      <p className="page-intro">Ustoz profilingiz faol. Materiallarni platformaga joylashtirish va o‘quvchilar uchun e’lon qilish bo‘yicha yordam jamoasiga murojaat qiling.</p>
      <div className="teacher-workspace">
        <article className="glass-card teacher-profile-card">
          <span className="dashboard-icon" aria-hidden="true">◎</span>
          <span className="section-kicker">Profil ma’lumotlari</span>
          <h2>{profile.full_name || "Ustoz"}</h2>
          <p>{profile.email || "Elektron pochta tasdiqlanmagan"}</p>
          <span className="profile-status"><span /> Ustoz hisobi</span>
        </article>
        <article className="teacher-next-step">
          <span className="section-kicker">Keyingi qadam</span>
          <h2>Darslaringizni o‘quvchilarga yetkazing.</h2>
          <p>Jonli dars jadvali, uchrashuv havolasi va video yozuvlarini boshqaring.</p>
          <div className="teacher-actions"><Link className="button" href="/classes">Darslar jadvalini ochish <span aria-hidden="true">↗</span></Link><Link className="text-link" href="/support">Jamoaga murojaat qilish</Link></div>
        </article>
      </div>
    </section>
  );
}
