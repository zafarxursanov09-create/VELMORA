"use client";

import { useState } from "react";
import { Button, ErrorState, LoadingState } from "@/components/UI";
import { sendSupportMessage } from "@/lib/api/support";
import { useProfile } from "@/lib/useProfile";

const questions = [
  ["Qanday qilib o‘quvchi sifatida ro‘yxatdan o‘taman?", "Kirish sahifasida “Ro‘yxatdan o‘tish”ni tanlang, “O‘quvchi” rolini belgilang va so‘ralgan ma’lumotlarni kiriting."],
  ["IELTS va CEFR kontentlari aralashib ketadimi?", "Yo‘q. O‘quv kabinetingizda faqat onboarding vaqtida tanlagan yo‘nalishingizga mos kontent ko‘rsatiladi."],
  ["Imtihon sanasi yoki maqsadimni o‘zgartira olamanmi?", "Hozircha bu o‘zgarishlar profil sozlamalari sahifasida mavjud emas. Yordam formasi orqali jamoaga murojaat qiling."],
];

export default function SupportPage() {
  const { user, profile, loading, error: profileError } = useProfile({ requireAuth: true });
  const [topic, setTopic] = useState("account");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function handleSubmit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      await sendSupportMessage(user, {
        name: profile?.full_name || user?.displayName || "",
        email: user?.email || "",
        topic,
        message,
      });
      setMessage("");
      setSuccess("Xabaringiz yuborildi. Murojaatingizni qabul qildik.");
    } catch (submitError) {
      setError(submitError.message || "Xabarni yuborib bo‘lmadi. Qayta urinib ko‘ring.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <div className="container"><LoadingState label="Yordam sahifasi yuklanmoqda..." /></div>;

  return (
    <section className="container page-wrap">
      <span className="section-kicker">Biz yordam beramiz</span>
      <h1 className="page-title">Yordam markazi</h1>
      <p className="page-intro">Ko‘p so‘raladigan savollarga javob toping yoki murojaatingizni yuboring.</p>
      {profileError ? <ErrorState message={profileError} /> : null}
      <div className="support-layout">
        <article className="glass-card support-content">
          <h2>Ko‘p so‘raladigan savollar</h2>
          <div className="faq-list">
            {questions.map(([question, answer]) => (
              <details key={question}>
                <summary>{question}</summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </article>
        <form className="glass-card support-content auth-form" onSubmit={handleSubmit}>
          <h2>Bizga yozing</h2>
          <p>Murojaatingiz qo‘llab-quvvatlash bo‘limiga yuboriladi.</p>
          <label className="form-field">
            Mavzu
            <select value={topic} onChange={(event) => setTopic(event.target.value)}>
              <option value="account">Hisob va kirish</option>
              <option value="learning">O‘qish va kontent</option>
              <option value="technical">Texnik muammo</option>
              <option value="other">Boshqa savol</option>
            </select>
          </label>
          <label className="form-field">
            Xabar
            <textarea required minLength={10} maxLength={5000} value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Muammo yoki savolingizni batafsil yozing" />
          </label>
          {error ? <ErrorState message={error} /> : null}
          {success ? <div className="notice notice-success" role="status">{success}</div> : null}
          <Button type="submit" disabled={busy || !user}>{busy ? "Yuborilmoqda..." : "Xabarni yuborish"}</Button>
        </form>
      </div>
    </section>
  );
}
