"use client";

import { useEffect, useState } from "react";
import { IconMoon, IconSun } from "./Icons";

export function ThemeToggle({ className = "" }) {
  const [theme, setTheme] = useState("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const savedTheme = localStorage.getItem("velmora_theme");
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.setAttribute("data-theme", savedTheme);
    } else {
      const initial = "dark";
      setTheme(initial);
      document.documentElement.setAttribute("data-theme", initial);
    }
  }, []);

  function toggleTheme() {
    const nextTheme = theme === "dark" ? "light" : "dark";
    setTheme(nextTheme);
    document.documentElement.setAttribute("data-theme", nextTheme);
    localStorage.setItem("velmora_theme", nextTheme);
  }

  if (!mounted) {
    return <button className={`theme-toggle ${className}`} aria-label="Mavzuni almashtirish" type="button" />;
  }

  return (
    <button
      className={`theme-toggle ${className}`}
      onClick={toggleTheme}
      type="button"
      title={theme === "dark" ? "Yorug‘ rejimga o‘tish" : "Tungi rejimga o‘tish"}
      aria-label="Mavzuni almashtirish"
    >
      {theme === "dark" ? (
        <span className="theme-toggle-inner">
          <IconSun size={18} />
          <span className="theme-text">Kunduzgi</span>
        </span>
      ) : (
        <span className="theme-toggle-inner">
          <IconMoon size={18} />
          <span className="theme-text">Tungi</span>
        </span>
      )}
    </button>
  );
}
