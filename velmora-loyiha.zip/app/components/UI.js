import Link from "next/link";
import { IconSparkles, IconCheckCircle } from "./Icons";

export function Button({ children, className = "", variant = "primary", ...props }) {
  const variantClass =
    variant === "secondary"
      ? "button-secondary"
      : variant === "quiet"
      ? "button-quiet"
      : variant === "light"
      ? "button-light"
      : "";

  return (
    <button className={`button ${variantClass} ${className}`.trim()} {...props}>
      {children}
    </button>
  );
}

export function Card({ children, className = "" }) {
  return <article className={`glass-card ${className}`.trim()}>{children}</article>;
}

export function Badge({ children, variant = "primary", className = "" }) {
  return <span className={`status-badge badge-${variant} ${className}`.trim()}>{children}</span>;
}

export function EmptyState({ title, description, action, href }) {
  return (
    <div className="empty-state">
      <span className="empty-orbit" aria-hidden="true">
        <IconSparkles size={24} />
      </span>
      <h3>{title}</h3>
      {description ? <p>{description}</p> : null}
      {action && href ? (
        <Link className="button button-small button-secondary" href={href}>
          {action} →
        </Link>
      ) : null}
    </div>
  );
}

export function LoadingState({ label = "Yuklanmoqda..." }) {
  return (
    <div className="loading-state" role="status" aria-live="polite">
      <span className="spinner" aria-hidden="true" />
      <span>{label}</span>
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  const rawMessage = typeof message === "string" ? message : message?.message || "Noma’lum xatolik yuz berdi.";
  const displayMessage = /permission-denied|missing or insufficient permissions/i.test(rawMessage)
    ? "Firebase Firestore ruxsat bermadi. Yangilangan firestore.rules qoidalarini Firebase loyihangizga nashr qiling va foydalanuvchi rolini tekshiring."
    : rawMessage;

  return (
    <div className="notice notice-error" role="alert">
      <span>{displayMessage}</span>
      {onRetry ? (
        <button className="text-link" type="button" onClick={onRetry}>
          Qayta urinish
        </button>
      ) : null}
    </div>
  );
}

export function LiveBackground() {
  return (
    <div className="ambient-background" aria-hidden="true">
      <span className="ambient-blob blob-purple" />
      <span className="ambient-blob blob-orange" />
      <span className="ambient-blob blob-teal" />
      <span className="ambient-blob blob-pink" />
      <span className="ambient-blob blob-green" />
      <span className="ambient-grid" />
    </div>
  );
}
