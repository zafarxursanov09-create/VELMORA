"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { signOut } from "firebase/auth";
import { getFirebaseServices } from "@/lib/firebase";
import { useProfile } from "@/lib/useProfile";
import { SupportAssistant } from "@/components/SupportAssistant";
import { ThemeToggle } from "@/components/ThemeToggle";

const navigation = [
  ["IELTS", "#learning"],
  ["CEFR", "#cefr"],
  ["Jonli darslar", "/classes"],
  ["Practice", "/practice"],
  ["Writing", "/writing"],
  ["Imkoniyatlar", "#features"],
  ["Ustozlar", "#teachers"],
  ["Yordam", "/support"],
];

export function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [signOutError, setSignOutError] = useState("");
  const pathname = usePathname();
  const router = useRouter();
  const { user, profile } = useProfile({ requireAuth: false });

  const accountLinks = profile?.role === "teacher"
    ? [["Ustoz paneli", "/teacher"], ["Jonli darslar", "/classes"], ["Yordam", "/support"]]
    : [["Dashboard", "/dashboard"], ["Profil", "/profile"], ["Practice", "/practice"], ["Writing Lab", "/writing"], ["Jonli darslar", "/classes"], ["Yordam", "/support"]];

  function closeMenu() {
    setMenuOpen(false);
  }

  async function handleSignOut() {
    setSignOutError("");
    try {
      const { auth } = getFirebaseServices();
      await signOut(auth);
      closeMenu();
      router.replace("/");
    } catch (error) {
      setSignOutError(error.message || "Hisobdan chiqib bo‘lmadi.");
    }
  }

  return (
    <header className="site-header">
      <nav className="container nav" aria-label="Asosiy navigatsiya">
        <Link className="brand" href="/" onClick={closeMenu}>
          <span className="brand-mark">V</span>
          <span className="brand-title">VELMORA</span>
          <span className="brand-badge">PRO</span>
        </Link>
        <button
          className="nav-toggle"
          type="button"
          aria-label={menuOpen ? "Menyuni yopish" : "Menyuni ochish"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span /><span /><span />
        </button>
        <div className={`nav-links ${menuOpen ? "open" : ""}`} id="primary-menu">
          {(user
            ? [
                ["Dashboard", "/dashboard"],
                ["Reading Practice", "/practice"],
                ["Writing Lab", "/writing"],
                ["Jonli Darslar", "/classes"],
                ["Yordam", "/support"],
              ]
            : navigation
          ).map(([label, href]) => {
            const target = href.startsWith("#") && pathname !== "/" ? `/${href}` : href;
            const isActive = pathname === href;
            return (
              <Link
                key={label}
                href={target}
                onClick={closeMenu}
                className={isActive ? "nav-link-active" : ""}
              >
                {label}
              </Link>
            );
          })}

          <ThemeToggle />

          {user ? (
            <details className="account-menu">
              <summary>
                <span className="account-avatar" aria-hidden="true">
                  {(profile?.full_name || user.email || "V").trim().charAt(0).toUpperCase()}
                </span>
                <span className="account-name">{profile?.full_name || user.email}</span>
                <span className="account-arrow" aria-hidden="true">▾</span>
              </summary>
              <div className="account-dropdown">
                <div className="dropdown-user-header">
                  <strong>{profile?.full_name || "O‘quvchi"}</strong>
                  <small>{user.email}</small>
                  {profile?.track ? (
                    <span className="user-track-pill">
                      {profile.track.toUpperCase()} {profile.target_level ? `Target: ${profile.target_level}` : ""}
                    </span>
                  ) : null}
                </div>
                {accountLinks.map(([label, href]) => (
                  <Link href={href} key={href} onClick={closeMenu}>
                    {label}
                  </Link>
                ))}
                <button type="button" onClick={handleSignOut} className="dropdown-logout-btn">
                  Chiqish
                </button>
              </div>
            </details>
          ) : (
            <div className="nav-auth-buttons">
              <Link className="login-link" href="/login" onClick={closeMenu}>
                Kirish
              </Link>
              <Link className="button button-small" href="/login?mode=register" onClick={closeMenu}>
                Boshlash <span aria-hidden="true">↗</span>
              </Link>
            </div>
          )}
        </div>
      </nav>
      {signOutError ? <div className="container nav-error" role="alert">{signOutError}</div> : null}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-inner">
        <div className="footer-col-brand">
          <Link className="brand" href="/">
            <span className="brand-mark">V</span>
            <span className="brand-title">VELMORA</span>
          </Link>
          <p className="footer-tagline">
            IELTS va CEFR imtihonlarida yuqori natijalarga erishish uchun zamonaviy, interaktiv o‘quv platformasi.
          </p>
          <div className="footer-badges">
            <span className="tech-badge">⚡ Real-time Firebase Sync</span>
            <span className="tech-badge">🎯 AI Powered Feedback</span>
          </div>
        </div>

        <div className="footer-nav-grid">
          <div>
            <h4>Ko‘nikmalar</h4>
            <div className="footer-link-list">
              <Link href="/practice">Reading Mini-test</Link>
              <Link href="/writing">Writing Simulyatori</Link>
              <Link href="/content/listening">Listening Darslari</Link>
              <Link href="/content/speaking">Speaking Part 1-3</Link>
              <Link href="/content/vocabulary">Lug‘at Boyligi</Link>
            </div>
          </div>
          <div>
            <h4>Platforma</h4>
            <div className="footer-link-list">
              <Link href="/assessment">CEFR Diagnostika</Link>
              <Link href="/classes">Jonli Darslar</Link>
              <Link href="/#teachers">Band 9 Ustozlar</Link>
              <Link href="/support">Yordam Markazi</Link>
              <Link href="/login?mode=register">Hisob Yaratish</Link>
            </div>
          </div>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} VELMORA Education Platform. Barcha huquqlar himoyalangan.</span>
        <div className="footer-bottom-links">
          <span>Maxfiylik siyosati</span>
          <span>Foydalanish shartlari</span>
        </div>
      </div>
    </footer>
  );
}

export function SupportFab() {
  return <SupportAssistant />;
}
