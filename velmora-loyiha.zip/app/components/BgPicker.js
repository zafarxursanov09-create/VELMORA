"use client";

import { useEffect, useState } from "react";

const options = [
  ["aurora", "Aurora", "linear-gradient(135deg,#a78bfa,#22d3ee)"],
  ["sunset", "Quyosh botishi", "linear-gradient(135deg,#fb923c,#f472b6)"],
  ["ocean", "Okean", "linear-gradient(135deg,#38bdf8,#2563eb)"],
  ["forest", "O‘rmon", "linear-gradient(135deg,#34d399,#14b8a6)"],
  ["night", "Tun", "linear-gradient(135deg,#312e81,#020617)"],
];

export function BgPicker() {
  const [bg, setBg] = useState("aurora");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    try {
      setBg(localStorage.getItem("velmora_bg") || "aurora");
    } catch {}
  }, []);

  function choose(id) {
    setBg(id);
    document.documentElement.setAttribute("data-bg", id);
    try {
      localStorage.setItem("velmora_bg", id);
    } catch {}
  }

  return (
    <div className={`bg-picker ${open ? "is-open" : ""}`}>
      <button type="button" className="bg-picker-toggle" onClick={() => setOpen((v) => !v)} aria-expanded={open} aria-label="Fonni tanlash">
        <span style={{ background: options.find((o) => o[0] === bg)?.[2] }} />
        Fon
      </button>
      {open ? (
        <div className="bg-picker-list" role="radiogroup" aria-label="Fon rangi">
          {options.map(([id, label, gradient]) => (
            <button key={id} type="button" role="radio" aria-checked={bg === id} title={label} aria-label={label} className={bg === id ? "on" : ""} style={{ background: gradient }} onClick={() => choose(id)} />
          ))}
        </div>
      ) : null}
    </div>
  );
}
