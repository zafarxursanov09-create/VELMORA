"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

const quickQuestions = [
  "CEFR test qanday ishlaydi?",
  "Parolni qanday tiklayman?",
  "Jonli darslarni qayerdan ko‘raman?",
];

export function SupportAssistant() {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [messages, setMessages] = useState([]);
  const endRef = useRef(null);

  useEffect(() => {
    if (open) endRef.current?.scrollIntoView({ block: "nearest" });
  }, [messages, open]);

  async function sendMessage(value = draft) {
    const message = value.trim();
    if (!message || busy) return;
    setDraft("");
    setError("");
    setMessages((current) => [...current, { role: "user", content: message }]);
    setBusy(true);
    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Javobni olishda xatolik yuz berdi.");
      setMessages((current) => [...current, { role: "assistant", content: payload.reply, mode: payload.mode }]);
    } catch (requestError) {
      setError(requestError.message || "Yordamchi bilan ulanib bo‘lmadi.");
    } finally {
      setBusy(false);
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
    sendMessage();
  }

  return (
    <div className="assistant-root">
      {open ? <section className="assistant-panel" aria-label="VELMORA yordamchi">
        <header className="assistant-header"><div><span className="assistant-live-dot" /><div><strong>VELMORA yordamchi</strong><small>24/7 · {messages.some((message) => message.mode === "ai") ? "AI yordamida" : "tezkor yordam"}</small></div></div><button type="button" aria-label="Yordamchini yopish" onClick={() => setOpen(false)}>×</button></header>
        <div className="assistant-messages" aria-live="polite">
          {!messages.length ? <div className="assistant-welcome"><span>Salom! Qanday yordam bera olaman?</span><p>Hisob, CEFR, Writing yoki jonli darslar haqida so‘rang.</p><div className="assistant-prompts">{quickQuestions.map((question) => <button type="button" key={question} onClick={() => sendMessage(question)}>{question}</button>)}</div></div> : messages.map((message, index) => <article className={`assistant-message ${message.role}`} key={`${message.role}-${index}`}><p>{message.content}</p>{message.mode === "faq" ? <small>Tezkor ma’lumot</small> : null}</article>)}
          {busy ? <p className="assistant-typing" role="status">Javob tayyorlanmoqda…</p> : null}
          {error ? <p className="assistant-error" role="alert">{error}</p> : null}
          <span ref={endRef} />
        </div>
        <form className="assistant-form" onSubmit={handleSubmit}><label className="sr-only" htmlFor="assistant-message">Xabaringiz</label><textarea id="assistant-message" rows="2" maxLength="1500" value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Savolingizni yozing..." /><button className="button" type="submit" disabled={busy || !draft.trim()} aria-label="Xabarni yuborish">↑</button></form>
        <footer className="assistant-footer"><span>Parol yoki to‘lov ma’lumotlarini yubormang.</span><Link href="/support">Yordam markazi ↗</Link></footer>
      </section> : null}
      <button className="support-fab assistant-launcher" type="button" aria-expanded={open} aria-label={open ? "Yordamchini yopish" : "24/7 yordam chatini ochish"} onClick={() => setOpen((value) => !value)}><span aria-hidden="true">{open ? "×" : "✳"}</span><span>{open ? "Yopish" : "24/7 yordam"}</span></button>
    </div>
  );
}