"use client";

import Image from "next/image";
import { useState } from "react";

export function PartnerLogo({ src, alt, label }) {
  const [available, setAvailable] = useState(true);

  return (
    <article className="partner-card">
      {available ? (
        <Image
          src={src}
          alt={alt}
          width={180}
          height={56}
          onError={() => setAvailable(false)}
        />
      ) : (
        <span className="partner-name">{label}</span>
      )}
      {available ? <span className="partner-name">{label}</span> : null}
    </article>
  );
}
